# Governance

**Maintainer.** A Claude Code agent run by Society AI is the repo's maintainer. It reviews,
approves and merges pull requests, turns issues agents and people flag into fixes and pull requests
(crediting the agent that found them), answers setup questions, tests Verified types with
real accounts before each release, and prepares releases. It never releases, never moves a registry
pin and cannot change the review machinery.

**Releases** are tags on `main` that only Lior pushes; the release workflow checks, builds and signs
them ([docs/contribute/releases.md](docs/contribute/releases.md)).

**Lior** (Society AI) gives the go on every release and owns the review machinery: `.github/`,
`docs/review.md` and `kit/conformance/`. A pull request cannot weaken the gates the maintainer agent
relies on.

**Labels.** Every released agent type is shown to everyone. **Verified** types are maintained and
tested by Society AI on every release (Grok Bot and Claude Code at launch); only the maintainer agent
sets `verified`. **Community** types are built and looked after by their contributors; the app shows
the date of their latest evidence.

**Switching a type off.** A type with failing checks or an unanswered security issue is fixed or
switched off: Society AI can stop new connections for a type at once (the kill switch), without a
release, and its connected agents are told.

**Sandboxing.** Runners run inside `core/` limits: on Linux with OpenShell they are enforced; on
macOS they are best effort, so review of what a runner declares matters most there.

"""Society AI Bridge — connects Claude Code to Society AI via WebSocket.

Receives task assignments and chat messages from Society AI, spawns Claude Code
CLI sessions to handle them, and reports results back.

Usage:
    python bridge.py

Env vars (see config.py for full validation):
    SOCIETY_AI_AUTH_TOKEN  — Your Society AI API key (required)
    AGENT_ROUTER_API_URL  — API URL (default: https://api.societyai.com)
    AGENT_NAME            — Agent name (default: claude-code)
    COMPANY_ID            — Default company UUID (optional)
    WORK_DIR              — Working directory for Claude Code (default: the agent's
                            own folder, <Society AI folder>/<agent>)
    MAX_CONCURRENT_TASKS  — Max parallel tasks (default: 3)
    EXECUTION_MODE        — "standard" (direct) or "secured" (OpenShell sandbox)
    SANDBOX_NAME          — Sandbox name (default: society-ai-agent)
    SANDBOX_TIMEOUT       — Per-task timeout in seconds (default: 600)
    MAX_RESULT_CHARS      — Result truncation cap (default: 16000)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import pathlib
import re
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time
import uuid

import certifi
import httpx
import websockets
from websockets.exceptions import ConnectionClosed, InvalidStatus

from core import bridge_ipc
from dataclasses import dataclass, field
from core.config import (
    AGENT_COMMAND,
    AGENT_ROUTER_API_URL,
    AGENT_TYPE,
    SOCIETY_AI_AUTH_TOKEN,
    AGENT_NAME,
    COMPANY_ID,
    API_HEADERS,
    EXECUTION_MODE,
    EXTRA_DIRS,
    MIRROR_SESSIONS,
    SANDBOX_NAME,
    SANDBOX_TIMEOUT,
    SESSION_MODE,
    SOCIETY_AI_BRIDGE_SOCKET,
    TRACKING_ENABLED,
    __version__,
    ws_url,
)
from core.contacts import (
    UPDATES_SESSION,
    Sender,
    clamp,
    classify_sender,
    contact_work_item_key,
    limit_line,
    owner_id_from_jwt,
    strip_private_blocks,
)
from dataclasses import replace
from core import folders
from core import removal
from core.attachments import FILES_DIRNAME, Attachment, fetch_all, parse_file_parts, prompt_block
from core.chat_context import chat_headers, valid_chat_id
from core.install_identity import install_identity
from typing import Any, Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
# The repo root: venv/, the agents' .env files and core/installer/ (this file is core/bridge.py).
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
logger = logging.getLogger("bridge")

# The agent's work folder. Unset = its own folder under the Society AI folder
# (folders.agent_workspace), resolved in main(), never this repository.
WORK_DIR = os.getenv("WORK_DIR", "").strip()
HEARTBEAT_INTERVAL = 60  # seconds (hub timeout is 90s)
# How long a fresh connection may wait for the hub to accept our
# registration. Heartbeats only run once registered, so without this a
# registration the hub never answers leaves the agent connected but
# unreachable indefinitely (seen 2026-10-07: jenkins sat 7 hours like that).
REGISTRATION_TIMEOUT_S = 30
MAX_RECONNECT_DELAY = 60
# How long a task.* frame waits for a registered connection before it is
# dropped: the longest reconnect backoff plus a fresh JWT and registration,
# with room. Matches the hub's delegation timeout.
TASK_FRAME_HOLD_S = 180
MAX_CONCURRENT_TASKS = max(1, int(os.getenv("MAX_CONCURRENT_TASKS", "3")))
MAX_TRACKED_SESSIONS = 1000  # cap history/lock maps to prevent memory leak
MAX_CHAT_HISTORY_TURNS = 10  # how many (user, assistant) pairs we keep per task
MAX_HISTORY_CHARS_PER_TURN = 8000  # per-side trim before stuffing into the next prompt
MAX_RESULT_CHARS = max(1000, int(os.getenv("MAX_RESULT_CHARS", "16000")))
TOOL_CONCURRENCY_RETRIES = 5  # retries when Claude API returns 400 for tool concurrency
TOOL_CONCURRENCY_BASE_DELAY = 3  # seconds between retries
JWT_EXCHANGE_TIMEOUT = 15
# After an update the new bridge starts before the updater has written how it went: wait
# this long for the outcome (the updater waits a minute for registration, a rollback another).
UPDATE_RESULT_WAIT_S = 180.0
UPDATE_RESULT_POLL_S = 3.0
HTTP_FETCH_TIMEOUT = 30
# Composed-dispatch block kinds that are session-scoped standing context:
# they hold across turns, so a warm session already carries them in its
# transcript and re-sending them every dispatch is pure token waste.
# Everything else (notably 'process') is per-event and always rendered.
# Unknown kinds render every time — a new kind must never go silently missing.
STANDING_BLOCK_KINDS = frozenset({"identity", "scope", "activity"})
# How much of a session transcript to scan when confirming channel delivery.
# The event we are looking for was pushed seconds ago, so it is always in the
# tail; a resumed session's full transcript can be megabytes.
_ACK_TAIL_BYTES = 256 * 1024
# A turn is over when its last assistant entry has one of these stop
# reasons ("tool_use" means more is coming; "refusal" is often followed by a
# fallback model's retry). How long to wait for that after the Stop hook.
FINAL_STOP_REASONS = frozenset({"end_turn", "stop_sequence", "max_tokens"})
TURN_FINAL_WAIT_S = 6.0
# Registration rejections that retrying can never clear. Anything else (a
# stale connection during a restart, a registry lookup that failed closed) is
# transient and worth backing off into. Matched case-insensitively on the
# hub's error string.
TERMINAL_REGISTRATION_ERRORS = (
    "owned by another user",
    "routing id mismatch",
)

# UUID pattern for input validation
_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)


# -- Runtime identity ---------------------------------------------------------
#
# Two version axes travel with every registration, and they are easy to
# confuse:
#   framework / framework_version — the software we run *on top of*, i.e. the
#       Claude Code CLI installed on this machine (e.g. "2.1.220"). It changes
#       whenever the user updates the CLI, independently of this package.
#   adapter_version — the version of *this* integration package (config
#       __version__), i.e. the bridge code speaking to the hub.
# Both fields are optional on the wire: older hubs simply ignore unknown
# params, so nothing needs to negotiate.

FRAMEWORK = "claude_code"  # Claude Code itself; the agent type registered is AGENT_TYPE
CLAUDE_CODE = FRAMEWORK

CLAUDE_VERSION_TIMEOUT = 2  # seconds — `claude --version` must never stall us

# "2.1.220 (Claude Code)" / "2.1.220" -> "2.1.220"
_CLI_VERSION_RE = re.compile(r"\b(\d+\.\d+(?:\.\d+)*(?:[-+][0-9A-Za-z.]+)?)\b")

_claude_cli_version: str | None = None
_claude_cli_version_probed = False
_claude_cli_version_lock = threading.Lock()


def parse_claude_version(output: str | None) -> str | None:
    """Extract the bare version token from `claude --version` output.

    Returns None for empty or unrecognized output rather than guessing.
    """
    if not output:
        return None
    match = _CLI_VERSION_RE.search(output.strip())
    return match.group(1) if match else None


def claude_cli_version() -> str | None:
    """Detected Claude Code CLI version, or None if it can't be determined.

    Probed at most once per process (the answer — including "unknown" — is
    cached), because registration happens on every reconnect and must never
    pay for a subprocess. Never raises: a missing binary, a non-zero exit,
    unexpected output or a hung process all resolve to None so that
    registration proceeds regardless.
    """
    global _claude_cli_version, _claude_cli_version_probed
    with _claude_cli_version_lock:
        if _claude_cli_version_probed:
            return _claude_cli_version
        _claude_cli_version_probed = True
        try:
            proc = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                text=True,
                timeout=CLAUDE_VERSION_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError) as e:
            # Binary missing, not executable, or timed out.
            logger.debug("Could not run `claude --version`: %s", e)
            return None
        if proc.returncode != 0:
            logger.debug(
                "`claude --version` exited %s: %s",
                proc.returncode,
                (proc.stderr or "").strip()[:200],
            )
            return None
        version = parse_claude_version(proc.stdout)
        if not version:
            logger.warning(
                "Unrecognized `claude --version` output: %r", (proc.stdout or "")[:200]
            )
            return None
        _claude_cli_version = version
        logger.debug("Claude Code CLI version: %s", version)
        return version


async def claude_cli_version_async() -> str | None:
    """Async wrapper — offloads the one-time probe so the event loop never
    blocks on the subprocess. Cache hits return without touching a thread."""
    if _claude_cli_version_probed:
        return _claude_cli_version
    try:
        return await asyncio.to_thread(claude_cli_version)
    except Exception as e:  # never let version detection break registration
        logger.debug("Claude Code version detection failed: %s", e)
        return None


# -- JWT token exchange -------------------------------------------------------

async def exchange_api_key_for_jwt(api_key: str, api_url: str = AGENT_ROUTER_API_URL) -> str:
    """Exchange a Society AI API key (sai_...) for a short-lived WS JWT.

    POST /auth/agent-token with {"api_key": "<key>"}
    Returns JWT valid for ~15 min. `api_url` is the backend the key was
    minted for — the agent's own, never assumed from the module default.

    Raises:
        AuthError on 401/403 (caller should not retry — bad credentials).
        httpx.HTTPError on transient failures (caller may retry with backoff).
    """
    url = f"{api_url}/auth/agent-token"
    ssl_ctx = ssl.create_default_context(cafile=certifi.where())
    async with httpx.AsyncClient(timeout=JWT_EXCHANGE_TIMEOUT, verify=ssl_ctx) as client:
        resp = await client.post(url, json={"api_key": api_key})

    if resp.status_code == 401 and resp.headers.get(AGENT_STATUS_HEADER, "").lower() == "deleted":
        raise AgentDeletedError("Society AI refused this agent's key: the agent was deleted there.")
    if resp.status_code in (401, 403):
        raise AuthError(
            f"Auth failed exchanging API key (HTTP {resp.status_code}). "
            f"Check that SOCIETY_AI_AUTH_TOKEN is a valid sai_... key. "
            f"Response: {resp.text[:200]}"
        )
    resp.raise_for_status()

    try:
        data = resp.json()
    except ValueError as e:
        raise RuntimeError(f"JWT exchange returned non-JSON response: {resp.text[:200]}") from e

    token = data.get("token") if isinstance(data, dict) else None
    if not token or not isinstance(token, str):
        raise RuntimeError(f"JWT exchange response missing 'token' field: {data}")

    expires_in = data.get("expires_in", 900) if isinstance(data, dict) else 900
    logger.info("JWT obtained (expires in %ds)", expires_in)
    return token


class AuthError(Exception):
    """Raised when API key authentication fails. Not retryable."""


class AgentDeletedError(AuthError):
    """The key was refused because its agent was deleted on Society AI."""


# Set to "deleted" by the router on a refused key whose agent was deleted
# (agent_router/auth/routes.py AGENT_STATUS_HEADER).
AGENT_STATUS_HEADER = "X-Society-Agent-Status"


# -- HTTP client for fetching task details ------------------------------------

_http_client: httpx.AsyncClient | None = None


def _upload_answer(content: Any) -> dict:
    """The JSON an upload_file call answered with, from its transcript tool_result. core/mcp_server.py
    _result writes an identity line, then the JSON; Claude Code records that string either as text
    blocks or wrapped as {"result": "<that string>"}."""
    if isinstance(content, list):
        content = "\n".join(str(c.get("text", "")) for c in content if isinstance(c, dict))
    if not isinstance(content, str) or "{" not in content:
        return {}
    try:
        answer = json.loads(content[content.index("{"):])
    except ValueError:
        return {}
    if not isinstance(answer, dict):
        return {}
    if "artifact_id" not in answer and isinstance(answer.get("result"), str):
        return _upload_answer(answer["result"])
    return answer


def _get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        _http_client = httpx.AsyncClient(timeout=HTTP_FETCH_TIMEOUT, verify=ssl_ctx)
    return _http_client


async def _close_http_client() -> None:
    global _http_client
    if _http_client and not _http_client.is_closed:
        try:
            await _http_client.aclose()
        except Exception as e:
            logger.warning("Error closing HTTP client: %s", e)
    _http_client = None


async def fetch_task_details(company_id: str, task_id: str) -> dict | None:
    """Fetch full task details from Society AI API."""
    if not _UUID_RE.match(company_id) or not _UUID_RE.match(task_id):
        logger.error("Invalid UUID in fetch_task_details: company=%s, task=%s", company_id, task_id)
        return None
    url = f"{AGENT_ROUTER_API_URL}/api/v1/companies/{company_id}/tasks/{task_id}"
    try:
        resp = await _get_http_client().get(url, headers=API_HEADERS)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error("Failed to fetch task %s: %s", task_id, e)
        return None


async def fetch_company_details(company_id: str) -> dict | None:
    """Fetch company context from Society AI API."""
    if not _UUID_RE.match(company_id):
        logger.error("Invalid UUID in fetch_company_details: %s", company_id)
        return None
    url = f"{AGENT_ROUTER_API_URL}/api/v1/companies/{company_id}"
    try:
        resp = await _get_http_client().get(url, headers=API_HEADERS)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.error("Failed to fetch company %s: %s", company_id, e)
        return None


# -- Claude Code process spawner ----------------------------------------------

def build_prompt(company: dict, task: dict, sandboxed: bool = False) -> str:
    """Build the prompt for a Claude Code session.

    Args:
        company: Company context dict.
        task: Task dict.
        sandboxed: If True, omit references to the user's local codebase since
            in secured mode the sandbox does not have access to it.
    """
    company_name = company.get("name", "Unknown")
    mission = company.get("mission", "")
    goals = company.get("goals", [])

    task_id = task.get("id", "")
    identifier = task.get("identifier", "")
    title = task.get("title", "")
    description = task.get("description", "")
    acceptance = task.get("acceptanceCriteria") or task.get("acceptance_criteria") or []
    company_id = task.get("companyId") or task.get("company_id") or ""

    goals_str = "\n".join(f"  - {g}" for g in goals) if goals else "  (none)"
    criteria_str = "\n".join(f"  - {c}" for c in acceptance) if acceptance else "  (none specified)"

    if sandboxed:
        env_note = (
            "You are running inside an isolated sandbox. You do NOT have access to the user's local files. "
            "Use the Society AI MCP tools (and any cloud APIs you've been granted) to do your work."
        )
    else:
        env_note = (
            "You are running on the user's machine in their working directory. "
            "You may read and modify files there as part of doing the work."
        )

    return f"""You are working as an agent in a Society AI company.

Company: {company_name}
Mission: {mission}
Goals:
{goals_str}

Task: {identifier} — {title}
Task ID: {task_id}
Company ID: {company_id}
Description: {description}
Acceptance Criteria:
{criteria_str}

Environment: {env_note}

Instructions:
1. First, update the task status to "in_progress" using the update_task tool.
2. Do the work — read/write files (standard mode), call MCP tools, run tests, etc.
3. When done, update the task with your result using update_task (status: "in_review", result: "<summary of what you did>").
4. If you're blocked and need input, update status to "blocked" with a blocked_reason, and send an inbox item (type: "input-required") explaining what you need.
5. If you want to report progress, use send_inbox_item (type: "status-update").

Do the work, then report your results."""


async def stream_claude_code(
    prompt: str,
    *,
    work_dir: str | None = None,
    extra_dirs: list[str] | None = None,
    chat_id: str = "",
) -> tuple[int, str, str | None, bool]:
    # The calling bridge's dirs; fall back to the process globals.
    work_dir = work_dir or WORK_DIR
    if extra_dirs is None:
        extra_dirs = EXTRA_DIRS
    """Spawn `claude -p --output-format stream-json` and collect its reply.
    Nothing about the run's own tool use or thinking is sent anywhere: the
    chat gets the final text only.

    Returns (exit_code, accumulated_text, session_id, had_error).
    `accumulated_text` is the assistant's final response text — sourced
    from `result.result` if Claude Code surfaced one, else stitched
    together from text content blocks. `had_error` is True if the
    `result` event reported `subtype != "success"` or `is_error: true`.

    This is the production path used by both the chat flow and the
    AgentOrg-task flow. We don't use `--resume` because Claude Code's
    session storage doesn't preserve thinking blocks byte-for-byte
    across replay (see v0.2.2 hotfix for details); instead the bridge
    inlines prior turns into the prompt itself.
    """
    cmd = [
        "claude",
        "-p", prompt,
        "--output-format", "stream-json",
        "--verbose",  # stream-json requires --verbose to actually emit each event
        # Headless mode: no human at the terminal to press 'y' on each
        # tool-use approval prompt, so MCP tools and Bash invocations
        # silently fail without this. Trust boundary is the same as
        # running `claude -p` yourself interactively — only the agent's
        # owner can deliver tasks (WS hub enforces creator_id match),
        # and file ops are still scoped by WORK_DIR + EXTRA_DIRS.
        "--permission-mode", "bypassPermissions",
    ]
    for extra_dir in extra_dirs:
        cmd.extend(["--add-dir", extra_dir])

    logger.info("Spawning Claude Code (streaming) in %s", work_dir)
    # asyncio.StreamReader's default line buffer is 64 KiB. Claude Code's
    # stream-json events can blow past that for a single line — a tool_result
    # carrying a 50 KB file becomes >80 KB after JSON escaping, and a Read on
    # a longer file blows it out entirely. Hitting the limit raises
    # LimitOverrunError mid-stream and the whole task fails. Bump it to 16
    # MiB so any reasonable single event fits in one readline().
    # The owner's chat this run answers, for the society-ai MCP server to
    # name on calls to the router (System of Record).
    env = None
    if valid_chat_id(chat_id):
        env = {**os.environ, "SOCIETY_AI_CHAT_ID": valid_chat_id(chat_id)}
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=work_dir,
        env=env,
        limit=16 * 1024 * 1024,
    )

    accumulated_text: list[str] = []
    final_result_text: str | None = None
    session_id: str | None = None
    had_error = False

    assert process.stdout is not None
    async for raw in process.stdout:
        line = raw.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            logger.debug("Non-JSON stream line: %s", line[:200])
            continue

        etype = event.get("type")
        if etype == "system" and event.get("subtype") == "init":
            session_id = event.get("session_id")
        elif etype == "assistant":
            for block in (event.get("message") or {}).get("content", []) or []:
                if isinstance(block, dict) and block.get("type") == "text":
                    text = block.get("text") or ""
                    if text:
                        accumulated_text.append(text)
        elif etype == "result":
            result_text = event.get("result")
            if isinstance(result_text, str) and result_text:
                final_result_text = result_text
            if event.get("subtype") != "success" or event.get("is_error"):
                had_error = True

    # Drain stderr (for diagnostics only — never re-sent to the hub).
    try:
        stderr = await process.stderr.read() if process.stderr else b""
    except Exception:
        stderr = b""
    await process.wait()
    exit_code = process.returncode or 0

    if stderr:
        stderr_text = stderr.decode("utf-8", errors="replace").strip()
        if stderr_text:
            logger.warning("Claude Code stderr: %s", stderr_text[:1000])

    output_text = final_result_text if final_result_text is not None else "".join(accumulated_text).strip()

    if exit_code != 0 or had_error:
        logger.error("Claude Code FAILED (exit=%d, had_error=%s): %s",
                     exit_code, had_error, (output_text or "")[:500])
    else:
        logger.info("Claude Code OK (session=%s, len=%d)",
                    session_id, len(output_text or ""))

    return exit_code, output_text, session_id, had_error


async def run_claude_code(
    prompt: str,
    session_id: str | None = None,
) -> tuple[int, str, str | None]:
    """Legacy non-streaming runner — kept for the secured-mode sandbox path
    until v0.4.x extends streaming into that flow too. Standard mode uses
    `stream_claude_code` instead.

    Retries automatically on tool-use concurrency errors (HTTP 400) which
    happen when another Claude Code session is actively using tools.
    """
    # Initialize before loop so we can always return safely, even if the
    # retry loop is configured to zero iterations.
    exit_code = 1
    output_text = ""
    returned_session_id = session_id

    for attempt in range(1, TOOL_CONCURRENCY_RETRIES + 1):
        cmd = [
            "claude",
            "-p", prompt,
            "--output-format", "json",
            "--permission-mode", "bypassPermissions",
        ]
        # Expand Claude Code's per-cwd file sandbox to include any directories
        # the user opted into via the EXTRA_DIRS env var. Each path becomes a
        # `--add-dir <path>` flag. Validation already happened at config load.
        for extra_dir in EXTRA_DIRS:
            cmd.extend(["--add-dir", extra_dir])
        if session_id:
            cmd.extend(["--resume", session_id])

        logger.info(
            "Spawning Claude Code in %s (session=%s, attempt=%d)",
            WORK_DIR, session_id or "new", attempt,
        )
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=WORK_DIR,
        )

        stdout, stderr = await process.communicate()
        exit_code = process.returncode or 0
        raw_output = stdout.decode("utf-8", errors="replace")

        if stderr:
            stderr_text = stderr.decode("utf-8", errors="replace")
            if stderr_text.strip():
                logger.warning("Claude Code stderr: %s", stderr_text[:1000])

        # Parse JSON output to extract result and session_id
        output_text = raw_output
        returned_session_id = session_id
        try:
            data = json.loads(raw_output)
            if isinstance(data, dict):
                output_text = data.get("result", raw_output)
                returned_session_id = data.get("session_id", session_id)
        except (json.JSONDecodeError, TypeError):
            pass  # Fall back to raw output

        # Retry on tool-use concurrency error
        if exit_code != 0 and "concurrency" in (output_text or "").lower():
            if attempt < TOOL_CONCURRENCY_RETRIES:
                delay = TOOL_CONCURRENCY_BASE_DELAY * attempt
                logger.warning(
                    "Tool concurrency conflict, retrying in %ds (attempt %d/%d)",
                    delay, attempt, TOOL_CONCURRENCY_RETRIES,
                )
                await asyncio.sleep(delay)
                continue
            else:
                logger.error(
                    "Tool concurrency conflict persisted after %d attempts",
                    TOOL_CONCURRENCY_RETRIES,
                )

        if exit_code != 0:
            logger.error("Claude Code FAILED (exit=%d): %s", exit_code, (output_text or "")[:500])
        else:
            logger.info("Claude Code OK (session=%s, len=%d)", returned_session_id, len(output_text or ""))
        return exit_code, output_text, returned_session_id

    return exit_code, output_text, returned_session_id


# -- WebSocket Bridge ---------------------------------------------------------

@dataclass
class AgentContext:
    """Everything that makes a bridge runner act AS one specific agent.

    Built from the process env (`from_env`), which the launcher sourced from
    the agent's `.env` file. This is the unit that decouples 'which agent'
    (token + identity + local file access) from the execution machinery.
    """
    name: str
    token: str
    work_dir: str
    extra_dirs: list[str]
    company_id: str
    api_url: str       # the Society AI backend this agent belongs to
    socket: str        # this agent's IPC socket path
    state_dir: str     # shipper state + channel sock live here (= dirname(socket))

    @classmethod
    def from_env(cls) -> "AgentContext":
        """The agent defined by the process environment."""
        return cls(
            name=AGENT_NAME,
            token=SOCIETY_AI_AUTH_TOKEN,
            work_dir=WORK_DIR,
            extra_dirs=list(EXTRA_DIRS),
            company_id=COMPANY_ID,
            api_url=AGENT_ROUTER_API_URL,
            socket=SOCIETY_AI_BRIDGE_SOCKET,
            state_dir=os.path.dirname(SOCIETY_AI_BRIDGE_SOCKET) or ".",
        )

    def session_env(self) -> dict:
        """Env injected into each spawned `claude` so its society-ai MCP acts
        as this agent, not whatever the user's own shell env says."""
        return {
            "SOCIETY_AI_AUTH_TOKEN": self.token,
            "AGENT_NAME": self.name,
            "COMPANY_ID": self.company_id or "",
            # Explicit, not inherited: a session must hit the same backend
            # its token was minted for even if the launching process's env
            # says otherwise.
            "AGENT_ROUTER_API_URL": self.api_url,
            "SOCIETY_AI_BRIDGE_SOCKET": self.socket,
            # Where download_file saves what it opens: the agent's work folder.
            "SOCIETY_AI_WORK_DIR": self.work_dir,
        }


class Bridge:
    # How often, while waiting on a turn, to check whether Claude Code wrote
    # an error into the transcript instead of an answer. Small enough that a
    # dead turn is reported in seconds rather than at the task timeout, large
    # enough to be free next to the file read it costs.
    API_ERROR_POLL_S = 3.0

    def __init__(self, ctx: "AgentContext | None" = None):
        # ctx carries this runner's agent identity + local file access.
        # Defaults to the process env, which the launcher sourced from the
        # agent's .env file.
        self.ctx = ctx or AgentContext.from_env()
        self.ws = None
        self.registered = False
        # Set while the current connection is registered; task.* frames wait
        # on it (see send()).
        self._registered_event = asyncio.Event()
        # Whether the current (or most recent) connection ever got past
        # registration. Drives the reconnect backoff reset; see run().
        self._conn_registered = False
        self.running = True
        self._active_tasks: set[str] = set()
        # Self-update (agent.update RPC). _inflight_dispatches counts
        # task.execute dispatches from acceptance (synchronously, in
        # handle_message) to completion — unlike _active_tasks it also
        # covers dispatches still queued on the semaphore, so an update
        # can never slip in between accepting a task and starting it.
        # _pending_update holds the approved update while work is in
        # flight; the last dispatch to finish starts it.
        self._inflight_dispatches = 0
        self._pending_update: dict | None = None
        self._semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)
        self._msg_counter = 0
        self._ws_jwt: str | None = None
        # The owner's user id, from the registration ack or our own WS JWT.
        # Until it is known, nothing is treated as coming from the owner.
        self._owner_user_id: str | None = None
        # Per-task chat conversation history. Each entry is a list of
        # {"user": str, "assistant": str} dicts. We maintain history ourselves
        # and inline it into the next prompt rather than using `claude --resume`,
        # because resuming a session that contains extended-thinking blocks
        # trips the Anthropic API's "thinking blocks cannot be modified"
        # integrity check on multi-turn replay.
        self._chat_history: dict[str, list[dict[str, str]]] = {}
        # Per-task lock to serialize messages in the same conversation
        self._task_locks: dict[str, asyncio.Lock] = {}

        # Session mode (v0.7): persistent interactive sessions per work item.
        # Hub + manager are created here; started in run(). Standard mode only.
        # Another local agent type (Codex, ...) runs through its runner (core/runner.py); everything below
        # about sessions, the channel and transcripts is Claude Code's own.
        self._runner = None
        self._runner_sessions: dict = {}  # conversation key -> the runner's SessionHandle
        if AGENT_TYPE != CLAUDE_CODE:
            from core.runner import load_runner

            self._runner = load_runner(AGENT_TYPE, AGENT_COMMAND)
            logger.info("Agent type %s: turns run through its %s runner", AGENT_TYPE, type(self._runner).__name__)
        self._session_mode = SESSION_MODE and EXECUTION_MODE != "secured" and self._runner is None
        self._channel_hub = None
        self._session_mgr = None
        self._shipper = None  # transcript mirroring; set below in session mode
        if self._session_mode:
            from agents.claude_code.runner.channel_hub import ChannelHub
            from agents.claude_code.runner.session_manager import SessionManager
            from core.policy import default_policy, apply_local_env
            # Channel hub socket lives beside this agent's IPC socket.
            hub_sock = os.path.join(self.ctx.state_dir, "channels.sock")
            self._channel_hub = ChannelHub(hub_sock)
            self._session_mgr = SessionManager(hub_sock)
            # Register this agent's policy (defaults + local env override now;
            # platform-fetched config is overlaid in run() once connected).
            # session_env makes every spawned claude act as THIS agent, even
            # when the user's own shell env names another one.
            pol = default_policy(self.ctx.name, self.ctx.work_dir, list(self.ctx.extra_dirs))
            apply_local_env(pol, self.ctx.name)
            pol.session_env = self.ctx.session_env()
            self._session_mgr.set_policy(pol)
            # event_id -> future awaiting the session's response.
            self._pending_session_tasks: dict[str, str] = {}
            # claude session_id -> {task_id, cwd} for a dispatch whose turn
            # has not ended yet. The Stop hook is what closes these out.
            self._session_awaiting: dict[str, dict] = {}
            logger.info("SESSION_MODE enabled: work runs in persistent sessions")

            # Transcript mirroring (recorded workspace). Ships per-turn JSONL
            # deltas of bridge-launched sessions to the platform. MIRROR=false
            # disables it; spawn mode never mirrors.
            if MIRROR_SESSIONS:
                from agents.claude_code.runner.transcript_shipper import TranscriptShipper
                # ctx.api_url, NOT the module-level default: the shipper must
                # hit the SAME backend this agent's token was minted for.
                self._shipper = TranscriptShipper(
                    self.ctx.api_url,
                    self.ctx.token,
                    state_dir=self.ctx.state_dir,
                )
                self._session_mgr.on_reap = self._on_session_reap
                self._shipper.on_chat_link = self._on_mirror_chat_link
                logger.info(
                    "Session mirroring enabled (conversation only; MIRROR=false to disable)"
                )

        # Session Trackers: one bridge per machine (whoever holds the lock)
        # keeps a Tracker for every Claude Code session here.
        self._tracker = None
        # claude session id -> set when that session's turn ends (Stop hook),
        # for replies carried into sessions started in Claude Code.
        self._direct_turn_events: dict[str, asyncio.Event] = {}
        if TRACKING_ENABLED and self.ctx.token and self._runner is None:
            from core.hook_common import discover_personas
            from agents.claude_code.runner.session_tracker import SessionTrackerRunner
            personas = discover_personas()
            self._tracker = SessionTrackerRunner(
                self.ctx.name, self.ctx.token, self.ctx.api_url,
                default_agent=personas[0]["name"] if personas else self.ctx.name,
            )

        # Sandbox executor for secured mode
        self._sandbox = None
        if EXECUTION_MODE == "secured":
            try:
                from core.sandbox import SandboxManager
            except ImportError:
                logger.error("EXECUTION_MODE=secured requires sandbox.py. Check your installation.")
                sys.exit(1)
            sandbox_env = {
                "SOCIETY_AI_AUTH_TOKEN": self.ctx.token,
                # Per-agent URL: the sandboxed session must hit the same
                # backend its token was minted for (matches session_env()).
                "AGENT_ROUTER_API_URL": self.ctx.api_url,
                "AGENT_NAME": self.ctx.name,
                "COMPANY_ID": self.ctx.company_id,
            }
            self._sandbox = SandboxManager(
                work_dir=self.ctx.work_dir,
                env_vars=sandbox_env,
                sandbox_name=SANDBOX_NAME,
                timeout=SANDBOX_TIMEOUT,
            )
            logger.info("SECURED mode: Claude Code will run inside OpenShell sandbox")
        else:
            logger.info("STANDARD mode: Claude Code will run directly on host (no sandbox)")

    def _next_id(self) -> str:
        self._msg_counter += 1
        return f"msg-{self._msg_counter}"

    async def send(self, message: dict):
        """Send a JSON-RPC message.

        A task.* frame waits, up to TASK_FRAME_HOLD_S, for a registered
        connection: the hub refuses task frames until agent.register is
        accepted on the connection, and between connections there is no
        socket at all. Without the hold, a task that finishes during a
        reconnect loses its reply and the chat waits forever. Everything
        else goes out at once (agent.register and heartbeat must), or not
        at all while disconnected.
        """
        method = message.get("method") or ""
        if method.startswith("task.") and not self._registered_event.is_set():
            try:
                await asyncio.wait_for(self._registered_event.wait(), TASK_FRAME_HOLD_S)
            except asyncio.TimeoutError:
                logger.error(
                    "%s for task %s dropped: no registered connection within %ds",
                    method, (message.get("params") or {}).get("task_id"), TASK_FRAME_HOLD_S,
                )
                return
        if self.ws:
            await self.ws.send(json.dumps(message))

    async def send_rpc(self, method: str, params: dict, msg_id: str | None = None) -> None:
        """Send a JSON-RPC request."""
        msg = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        if msg_id:
            msg["id"] = msg_id
        await self.send(msg)

    # -- Registration --------------------------------------------------------

    async def obtain_jwt(self):
        """Exchange API key for a short-lived WS JWT.

        Called once per (re)connect — the JWT is only used at register time;
        the hub does not re-validate it for the lifetime of the WS connection,
        so we don't need a proactive refresh loop. If the connection drops,
        the next reconnect attempt fetches a fresh JWT.
        """
        self._ws_jwt = await exchange_api_key_for_jwt(self.ctx.token, self.ctx.api_url)
        if not self._owner_user_id:
            self._owner_user_id = owner_id_from_jwt(self._ws_jwt)
            if not self._owner_user_id:
                logger.error(
                    "Could not read the owner id from the login token; every "
                    "request will be handled as a contact at 'chat'"
                )

    def _contact_limit(self) -> str:
        """The machine owner's cap for every contact (chat | read | act)."""
        if self._session_mgr is not None:
            return self._session_mgr.policy(self.ctx.name).contact_permission_limit
        return os.getenv("CONTACT_PERMISSION_LIMIT", "act").strip() or "act"

    async def register(self):
        """Register this agent with the hub using the WS JWT."""
        if not self._ws_jwt:
            await self.obtain_jwt()
        # framework/framework_version describe the runtime we sit on top of
        # (the Claude Code CLI); adapter_version is this package. See the
        # "Runtime identity" block near the top for why both exist.
        params = {
            "agent_name": self.ctx.name,
            "auth_token": self._ws_jwt,
            "visibility": "private",
            "framework": AGENT_TYPE,
            "adapter_version": __version__,
            # Lets the Contacts tab show "limited on this computer". The
            # bridge enforces it whatever the platform stores.
            "contact_permission_limit": self._contact_limit(),
            # The Connect install this bridge runs from (a hash, never the path), so the
            # agents sharing it get one update offer.
            **install_identity(),
        }
        framework_version = (
            await self._runner.version() if self._runner is not None else await claude_cli_version_async()
        )
        if framework_version:
            # Omitted entirely when undetectable — never send an empty string.
            params["framework_version"] = framework_version
        await self.send_rpc("agent.register", params, msg_id=self._next_id())

    async def _registration_watchdog(self, ws) -> None:
        """Drop a connection the hub has not accepted within
        REGISTRATION_TIMEOUT_S, so the reconnect loop tries again."""
        await asyncio.sleep(REGISTRATION_TIMEOUT_S)
        if not self._conn_registered and self.ws is ws:
            logger.error(
                "Hub did not answer registration within %ds; reconnecting",
                REGISTRATION_TIMEOUT_S,
            )
            await ws.close()

    # -- Heartbeat -----------------------------------------------------------

    async def heartbeat_loop(self):
        """Send heartbeats to keep the connection alive."""
        while self.running:
            await asyncio.sleep(HEARTBEAT_INTERVAL)
            if self.ws and self.registered:
                try:
                    await self.send_rpc("heartbeat", {})
                    logger.debug("Heartbeat sent")
                except Exception as e:
                    logger.warning("Heartbeat failed: %s", e)
                    break

    # -- Message handling ----------------------------------------------------

    async def handle_message(self, raw: str):
        """Route an incoming JSON-RPC message."""
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Invalid JSON: %s", raw[:200])
            return
        if not isinstance(msg, dict):
            logger.warning("Non-object JSON-RPC frame: %s", str(raw)[:200])
            return

        msg_id_raw = msg.get("id")
        # Hub may send numeric ids; we always use string keys in our maps.
        msg_id = str(msg_id_raw) if msg_id_raw is not None else None

        # --- Responses to requests we sent --------------------------------
        if "result" in msg or "error" in msg:
            err = msg.get("error")
            result = msg.get("result")

            # The registration ack (the only request we wait on).
            if err is not None:
                logger.error("RPC error: %s", err)
                return
            if isinstance(result, dict) and "registered" in result:
                if result["registered"]:
                    self.registered = True
                    self._registered_event.set()
                    # Registration, not the socket handshake, is what makes
                    # this connection usable. The reconnect backoff resets
                    # here so that a hub which accepts the socket and then
                    # rejects us cannot hold the delay at its floor forever.
                    self._conn_registered = True
                    owner_id = result.get("owner_user_id")
                    if isinstance(owner_id, str) and owner_id.strip():
                        self._owner_user_id = owner_id.strip()
                    owner_name = result.get("owner_name")
                    if (self._session_mgr is not None and isinstance(owner_name, str)
                            and owner_name.strip() and not os.getenv("OWNER_NAME", "").strip()):
                        self._session_mgr.policy(self.ctx.name).owner_label = \
                            owner_name.strip().split()[0]
                    logger.info("Registered as %s", result.get("agent_id", self.ctx.name))
                else:
                    reason = str(result.get("error") or "")
                    if any(t in reason.lower() for t in TERMINAL_REGISTRATION_ERRORS):
                        # Nothing about this clears on its own. Retrying is a
                        # hot loop against the hub that can never succeed, so
                        # stop and leave the reason where the owner sees it.
                        logger.error(
                            "Registration refused permanently (%s). This will not "
                            "resolve by retrying; the agent's owner or routing id "
                            "has to be corrected on the platform. Stopping.",
                            reason,
                        )
                        self.running = False
                        try:
                            if self.ws:
                                await self.ws.close(code=1000, reason="registration refused")
                        except Exception:
                            pass
                        return
                    # Transient reject (commonly "already connected" during a
                    # restart, while the hub still holds this agent's prior
                    # connection): drop and let the
                    # reconnect loop retry, now with real backoff behind it.
                    # The stale connection clears on the hub's heartbeat
                    # timeout, after which re-registration succeeds.
                    logger.error(
                        "Registration failed (%s) — reconnecting to retry",
                        reason,
                    )
                    await asyncio.sleep(5)
                    try:
                        if self.ws:
                            await self.ws.close(code=1012, reason="re-register")
                    except Exception:
                        pass
            return

        # --- Notifications / inbound requests -----------------------------
        method = msg.get("method")
        params = msg.get("params", {}) or {}

        if method == "connection.established":
            logger.info("Connected: %s", params.get("connection_id"))
            await self.register()

        elif method == "heartbeat_ack":
            logger.debug("Heartbeat ack received")

        elif method == "task.execute":
            # Counted here (synchronously) rather than inside the task so a
            # just-accepted dispatch already defers an agent.update that
            # arrives on the very next frame.
            self._inflight_dispatches += 1
            asyncio.create_task(self.handle_task_execute(msg_id, params))

        elif method == "agent.update":
            await self.handle_agent_update(msg_id, params)

        elif method == "agent.removed":
            self.handle_agent_removed(params)

        else:
            logger.debug("Unhandled method: %s", method)

    # -- Agent deleted on Society AI -----------------------------------------

    def handle_agent_removed(self, params: dict) -> None:
        """The hub says this agent was deleted (agent.removed), then closes the link."""
        name = (params or {}).get("agent_name")
        if name and name != self.ctx.name:
            logger.warning("Ignoring agent.removed for %s: this bridge is %s", name, self.ctx.name)
            return
        self.remove_self("Society AI says the agent was deleted")

    def remove_self(self, why: str) -> None:
        """Remove this agent from the computer (service, key, logs), keep its
        folder and sessions, and stop. Removes nothing unless the persona's key
        file names this agent, so a bridge started by hand never removes another."""
        logger.warning("%s: removing %s from this computer; its folder and sessions stay", why, self.ctx.name)
        try:
            result = removal.remove_persona(
                os.getenv("SOCIETY_AI_PERSONA", ""),
                reason=removal.DELETED_ON_SOCIETY_AI,
                from_bridge=True,
                expected_agent=self.ctx.name,
            )
            logger.info("Removed %s; kept %s", ", ".join(result["removed"]) or "nothing", ", ".join(result["kept"]) or "nothing")
        except Exception as e:  # noqa: BLE001 - stopping matters more than the cleanup
            logger.error("Could not remove %s from this computer: %s", self.ctx.name, e)
        self.stop()

    # -- Task execution ------------------------------------------------------

    async def handle_task_execute(self, msg_id: str | None, params: dict):
        """Handle a task.execute message from the hub.

        Two flows:
        1. Chat flow — direct message from a user, no metadata.company_id.
           Respond with simple text via task.complete.
        2. AgentOrg trigger flow — has metadata.company_id + agent_task_id.
           Fetch full context, spawn Claude Code with MCP tools.
        """
        task_id = params.get("id", msg_id or str(uuid.uuid4()))
        metadata = params.get("metadata", {}) or {}
        company_id = metadata.get("company_id") or self.ctx.company_id
        agent_task_id = metadata.get("agent_task_id")

        # Persona context injected by the platform on every dispatch
        # (task_manager._inject_card_instructions). agent_instructions is
        # the agent-level text authored on the agent's edit page;
        # skill_instructions arrives pre-matched as the invoked skill's
        # string (the router injects skill_instructions[skill_used], not
        # the whole dict) — tolerate non-strings from older routers.
        agent_instructions = metadata.get("agent_instructions")
        if not isinstance(agent_instructions, str):
            agent_instructions = ""
        skill_instructions = metadata.get("skill_instructions")
        if not isinstance(skill_instructions, str):
            skill_instructions = ""
        instructions_block = self._format_instructions_block(
            agent_instructions.strip(), skill_instructions.strip()
        )

        # Extract user message text
        message = params.get("message", {}) or {}
        parts = message.get("parts", []) or []
        user_text = ""
        for part in parts:
            if isinstance(part, dict) and part.get("type") == "text":
                user_text += part.get("text", "")
            elif isinstance(part, str):
                user_text += part
        # Files travel as references (artifact ids); the session path
        # downloads them and names them in the prompt.
        attachments = parse_file_parts(parts)

        # Composed dispatch (docs/design/agent-instruction-hierarchy.md):
        # routers that run the dispatch composer send structured fields —
        # frame (authenticated facts), blocks (labeled sections), body
        # (rendered work item), next_steps, protocol. When the frame is
        # present we render fields and skip every legacy text heuristic;
        # the legacy path stays as fallback for pre-composer routers and
        # is deleted when the router's dual-emit window closes.
        frame = metadata.get("frame") if isinstance(metadata.get("frame"), dict) else None

        # Who sent this: the owner, or a contact with a permission level.
        # A contact never sees the owner's private standing blocks, and its
        # level is capped by this machine's limit.
        sender = classify_sender(frame, metadata, self._owner_user_id)
        if not sender.is_owner:
            sender = replace(sender, permission=clamp(sender.permission, self._contact_limit()))
            metadata = strip_private_blocks(metadata)

        # Send-as-supervisor (legacy path only): the platform relays a
        # supervisor-suggested message the owner approved. Composed
        # dispatches carry this in the frame (from=supervisor) instead.
        from_supervisor = metadata.get("from_supervisor")
        if sender.is_owner and frame is None and isinstance(from_supervisor, str) and from_supervisor.strip():
            user_text = (
                f"[Message from your supervisor ({from_supervisor.strip()}) — "
                "relayed with your owner's approval. Treat it as direction "
                "from the supervisor.]\n\n" + user_text
            )

        logger.info(
            "Task received: %s (agent_task=%s, company=%s, from=%s)",
            task_id, agent_task_id, company_id,
            "owner" if sender.is_owner else f"{sender.label} [{sender.permission}]",
        )
        logger.info("Message: %s", user_text[:200])

        # Per-task lock: serialize messages in the same conversation so
        # appends to chat_history happen in the same order the user sent them.
        if task_id not in self._task_locks:
            self._task_locks[task_id] = asyncio.Lock()
        task_lock = self._task_locks[task_id]

        # If we're at the concurrency cap, this acquire will block. Log it
        # after we know we're queuing (i.e. acquire didn't return immediately).
        if self._semaphore.locked() or len(self._active_tasks) >= MAX_CONCURRENT_TASKS:
            logger.info(
                "At max concurrent tasks (%d), queuing task %s",
                MAX_CONCURRENT_TASKS, task_id,
            )

        async with self._semaphore:
            async with task_lock:
                self._active_tasks.add(task_id)
                try:
                    if self._runner is not None and not sender.is_owner and not self._runner.capabilities.enforces_limits:
                        # This type's runner cannot hold a contact to its level (the agent's own tools
                        # are outside core's reach), so it serves the owner only.
                        logger.warning("Refusing request %s from contact %s: the %s runner cannot enforce "
                                       "contact limits", task_id, sender.label, AGENT_TYPE)
                        await self._send_task_complete(
                            task_id, "This agent can't take requests from contacts yet.", exit_code=1,
                        )
                    elif self._session_mode or self._runner is not None:
                        # v0.7: dispatch into a persistent per-work-item session.
                        # Stable key gives task rework continuity (resume same
                        # session); chat falls back to sessionId/chat/task_id.
                        # The chat an answer to the agent's own inbox item or
                        # held action goes back to: the chat it asked from.
                        inbox_chat = inbox_answer_chat(sender, frame, metadata)
                        if sender.session:
                            # One long-lived session (Society AI updates for the Lead).
                            work_item_key = sender.session
                        elif inbox_chat and self._session_mgr is not None and self._session_mgr.get(inbox_chat):
                            # The session that asked (a task session has its chat
                            # aliased to it), not a new one per answer.
                            work_item_key = inbox_chat
                        elif sender.is_owner:
                            work_item_key = (
                                agent_task_id
                                or params.get("sessionId")
                                or metadata.get("chat_id")
                                or task_id
                            )
                        else:
                            work_item_key = contact_work_item_key(
                                sender, frame, metadata, params, task_id
                            )
                        protocol_text = ""
                        standing_text = ""
                        if frame is not None:
                            # v0.10: everything derives from frame FIELDS —
                            # no text sniffing. Session kind comes from the
                            # cause: task work (assignee/reviewer) is a real
                            # work session; messages are chats; wakes, status
                            # notifications and inbox pings are automation
                            # ('trigger' keeps them out of Sessions lists and
                            # never re-wakes the supervisor).
                            cause = str(frame.get("cause") or "message")
                            role = frame.get("role")
                            body = metadata.get("body")
                            work_text = body if isinstance(body, str) and body.strip() else user_text
                            if (
                                cause == "task"
                                and agent_task_id
                                and role in ("assignee", "reviewer")
                            ):
                                kind = "task_assigned"
                            elif cause == "message":
                                kind = "chat"
                            else:
                                kind = "trigger"
                            standing_text, content = self._render_composed_prompt(
                                metadata, frame, work_text
                            )
                            protocol_text = self._protocol_text(metadata)
                            title = self._derive_session_title(work_text)
                        elif not sender.is_owner:
                            # A contact through a pre-composer router: just
                            # the request, none of the owner's primers.
                            content = user_text
                            title = self._derive_session_title(user_text)
                            kind = "task_assigned" if agent_task_id else "chat"
                        else:
                            # Legacy fallback (pre-composer router): sniff
                            # mode from text, prepend primers. Delete when
                            # the router dual-emit window closes.
                            is_background = bool(agent_task_id) or user_text.lstrip().startswith("[Trigger:")
                            primer = (
                                self._bridge_context_primer_background(trigger_reason="task")
                                if is_background
                                else self._bridge_context_primer_chat(work_item_key, 0)
                            )
                            content = primer + instructions_block + user_text
                            title = self._derive_session_title(user_text)
                            stripped = user_text.lstrip()
                            if agent_task_id and (
                                stripped.startswith("[Trigger: task_assigned]")
                                or not stripped.startswith("[Trigger:")
                            ):
                                kind = "task_assigned"   # real work on the task
                            elif is_background:
                                kind = "trigger"
                            else:
                                kind = "chat"
                        permission = None
                        if not sender.is_owner:
                            # The agent learns what it may actually do here,
                            # on every request: the level can change between
                            # messages, and the machine limit can make it
                            # lower than what the platform says.
                            content = limit_line(sender) + "\n\n" + content
                            permission = sender.permission
                        # Sidebar groups are per sender and can hold several
                        # of this machine's agents, so titles name the agent.
                        agent_label = os.getenv("DISPLAY_NAME", "").strip() or self.ctx.name
                        title = f"{agent_label}: {title}"
                        # Delivery ticks under the owner's message in the app
                        # (Sent -> Received). Only the owner's own chat turns.
                        delivery_chat_id = (
                            _owner_chat_id(metadata)
                            if sender.is_owner and kind == "chat" else None
                        )
                        if self._runner is not None:
                            await self._execute_via_runner(
                                task_id, str(work_item_key), content, standing_text=standing_text,
                                sender=sender, permission=permission, delivery_chat_id=delivery_chat_id,
                                attachments=attachments,
                            )
                            return
                        await self._execute_via_session(
                            task_id, str(work_item_key), title, content, kind=kind,
                            protocol_text=protocol_text, standing_text=standing_text,
                            sender=sender, permission=permission,
                            delivery_chat_id=delivery_chat_id,
                            attachments=attachments,
                            inbox_chat=inbox_chat,
                        )
                    elif not sender.is_owner:
                        # The one-shot spawn path (session mode off, or the
                        # secured sandbox) runs with full permissions and has
                        # no way to limit them, so it serves the owner only.
                        logger.warning(
                            "Refusing request %s from contact %s: session mode is off",
                            task_id, sender.label,
                        )
                        await self._send_task_complete(
                            task_id,
                            "This agent can't take requests from contacts right now.",
                            exit_code=1,
                        )
                    elif agent_task_id and company_id:
                        # AgentOrg trigger flow — full context + Claude Code spawn
                        await self._execute_agentorg_task(
                            task_id, company_id, agent_task_id,
                            instructions_block=instructions_block,
                        )
                    else:
                        # Chat flow OR personal-task trigger (no company_id) —
                        # direct message, respond via Claude Code. Pass
                        # agent_task_id through so the chat task can pick the
                        # right context primer (active chat vs background).
                        await self._execute_chat_task(
                            task_id, user_text, agent_task_id=agent_task_id,
                            instructions_block=instructions_block,
                            chat_id=_owner_chat_id(metadata) or "",
                        )
                except Exception as e:
                    logger.exception("Task %s failed with unhandled exception", task_id)
                    await self._send_task_complete(
                        task_id, f"Internal error: {type(e).__name__}: {e}", exit_code=1
                    )
                finally:
                    self._active_tasks.discard(task_id)
                    self._inflight_dispatches = max(0, self._inflight_dispatches - 1)
                    # A user-approved update that arrived mid-work runs once
                    # the last in-flight dispatch drains.
                    if self._pending_update and self._inflight_dispatches == 0:
                        logger.info("Last in-flight task finished; starting the deferred update")
                        self._start_pending_update()

    # -- Self-update (agent.update) ------------------------------------------

    async def handle_agent_update(self, msg_id: str | None, params: dict):
        """Handle an `agent.update` RPC from the hub (sent when the owner
        approves an update). Ack immediately, then either start the update
        now (idle) or defer it until the last in-flight dispatch finishes.

        The update itself runs in ./connect update, spawned fully detached — the
        updater restarts (and can roll back) this very process, so none of
        that logic may live in here.
        """
        latest = str((params or {}).get("latest_version") or "").strip()
        reason = str((params or {}).get("reason") or "").strip()
        if msg_id is not None:
            await self.send({"jsonrpc": "2.0", "id": msg_id, "result": {"status": "accepted"}})
        logger.info(
            "Update requested (latest_version=%s, reason=%s)", latest or "?", reason or "?"
        )
        self._pending_update = {"latest_version": latest, "reason": reason}
        if self._inflight_dispatches > 0:
            logger.info(
                "Update deferred: %d dispatch(es) in flight; it starts when the last one finishes",
                self._inflight_dispatches,
            )
        else:
            self._start_pending_update()

    def _start_pending_update(self) -> None:
        """Spawn ./connect update fully detached and clear the pending flag.

        Detachment (start_new_session=True → its own session + process
        group, stdio to a log file, never waited on) is what lets the
        updater outlive this bridge: the restart it performs kills our
        process group, and the updater must survive that to verify the new
        version or roll back.
        """
        update = self._pending_update
        if not update:
            return
        self._pending_update = None
        repo_dir = REPO_ROOT
        script = os.path.join(repo_dir, "core", "installer", "update.sh")
        persona = self._derive_persona()
        cmd = [script] + ([persona] if persona else [])
        log_path = os.path.join(self.ctx.state_dir, "update.log")
        # The version this process runs: when the folder is already on the latest release
        # (another agent on this machine updated it), the updater still restarts this bridge.
        env = {**os.environ, "SOCIETY_AI_RUNNING_VERSION": __version__}
        try:
            os.makedirs(self.ctx.state_dir, exist_ok=True)
            with open(log_path, "ab") as log_file:
                subprocess.Popen(
                    cmd,
                    cwd=repo_dir,
                    env=env,
                    stdin=subprocess.DEVNULL,
                    stdout=log_file,
                    stderr=log_file,
                    start_new_session=True,
                    close_fds=True,
                )
            logger.info(
                "Updater spawned detached (%s); progress in %s",
                " ".join(cmd), log_path,
            )
        except Exception:
            logger.exception("Failed to spawn the updater")

    def _derive_persona(self) -> str:
        """Which persona this bridge runs as ("" = the primary), derived the
        same way the launchers map personas to env files: the primary sources
        .env, a persona sources .env.<name>. We reverse that mapping by
        finding the env file whose AGENT_NAME is ours (mirrors the
        backup/special-file filters setup.sh relies on)."""
        repo_dir = REPO_ROOT
        primary = _read_env_file(os.path.join(repo_dir, ".env"))
        if (primary.get("AGENT_NAME") or "").strip() == self.ctx.name:
            return ""
        try:
            entries = sorted(os.listdir(repo_dir))
        except OSError:
            return ""
        for entry in entries:
            if not entry.startswith(".env.") or entry in (".env.example", ".env.defaults"):
                continue
            persona = entry[len(".env."):]
            if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,62}", persona):
                continue
            if re.search(r"\.?bak-\d+$", persona):
                continue
            env = _read_env_file(os.path.join(repo_dir, entry))
            if (env.get("AGENT_NAME") or "").strip() == self.ctx.name:
                return persona
        return ""

    async def _resolve_owner_label(self) -> str:
        """The owner's name for the sidebar group of their sessions
        ("Society-AI-<name>"): OWNER_NAME from ./connect status, else the first
        name on their Society AI profile, else their email's first part."""
        configured = os.getenv("OWNER_NAME", "").strip()
        if configured:
            return configured
        try:
            resp = await _get_http_client().get(
                f"{self.ctx.api_url}/api/v1/users/context",
                headers={"Authorization": f"Bearer {self.ctx.token}",
                         "User-Agent": f"society-ai-connect/{__version__}"},
            )
            if resp.status_code < 400:
                data = resp.json()
                user = data.get("user", data) if isinstance(data, dict) else {}
                name = str(user.get("name") or "").strip()
                if name:
                    return name.split()[0]
                email = str(user.get("email") or "").strip()
                if "@" in email:
                    local = re.split(r"[._+-]", email.split("@")[0])[0]
                    if local:
                        return local[:1].upper() + local[1:]
        except Exception as e:
            logger.debug("Owner name lookup failed: %s", e)
        return "Owner"

    async def _report_delivery(self, chat_id: str, state: str) -> None:
        """Tell the app how the owner's message is getting to this agent, so
        the ticks under it move (waking, received, unreachable). The app
        accepts it only for the owner's own chat with this agent while a
        delivery is pending, so a rejection is expected and not an error.
        Never raises: ticks are a courtesy, not part of the reply path."""
        try:
            resp = await _get_http_client().post(
                f"{self.ctx.api_url}/api/v1/chats/{chat_id}/delivery",
                json={"state": state},
                headers={
                    "Authorization": f"Bearer {self.ctx.token}",
                    "Content-Type": "application/json",
                    "User-Agent": f"society-ai-connect/{__version__}",
                    **chat_headers(chat_id),
                },
            )
            if resp.status_code < 400:
                logger.info("Delivery %s reported for chat %s", state, chat_id[:8])
            else:
                logger.debug("Delivery %s for chat %s not taken (HTTP %s)",
                             state, chat_id[:8], resp.status_code)
        except Exception as e:
            logger.debug("Delivery %s report failed: %s", state, e)

    async def _stream_delivery(self, task_id: str, state: str) -> None:
        """The delivery state as a `delivery` data part on the task's stream
        (task.status, not final). Same never-raise rule as the report."""
        try:
            await self._send_status_update(
                task_id, [_data_part("delivery", f"delivery-{task_id}", {"state": state})]
            )
        except Exception as e:
            logger.debug("Delivery %s stream update failed: %s", state, e)

    async def _report_update_outcome(self) -> None:
        """If update.sh left an outcome marker, post it to the owner's feed
        and delete the marker. Fire-and-forget at startup: never blocks or
        fails the boot, and the marker is only deleted after a successful
        post so a failed post retries at the next start.

        The updater restarts this bridge before it knows the outcome (it waits
        for the new process to register), so while its pending file is there
        the outcome is waited for, up to UPDATE_RESULT_WAIT_S."""
        marker = os.path.join(self.ctx.state_dir, "update-result.json")
        pending = os.path.join(self.ctx.state_dir, "update-pending.json")
        try:
            waited = 0.0
            while (not os.path.exists(marker) and os.path.exists(pending)
                   and waited < UPDATE_RESULT_WAIT_S):
                await asyncio.sleep(UPDATE_RESULT_POLL_S)
                waited += UPDATE_RESULT_POLL_S
            if not os.path.exists(marker):
                return
            try:
                with open(marker, encoding="utf-8") as f:
                    data = json.load(f)
            except (ValueError, OSError) as e:
                # Unreadable marker: nothing to report, and retrying next
                # boot won't help — drop it.
                logger.warning("Unreadable update marker %s (%s); removing it", marker, e)
                try:
                    os.remove(marker)
                except OSError:
                    pass
                return

            from_v = str(data.get("from") or "an earlier version")
            to_v = str(data.get("to") or "the new version")
            if data.get("ok"):
                message = f"Updated from {from_v} to {to_v}."
            else:
                error = str(data.get("error") or "unknown error")
                if data.get("rolled_back"):
                    message = f"Update to {to_v} failed ({error}), rolled back to {from_v}."
                else:
                    message = f"Update to {to_v} failed ({error}); still on {from_v}."

            # Same endpoint + auth the MCP post_feed tool uses
            # (POST /api/v1/feed with the agent's own token) — but sent with
            # this bridge's ctx.token, so the agent reports as itself.
            headers = {
                "Authorization": f"Bearer {self.ctx.token}",
                "Content-Type": "application/json",
                "User-Agent": f"society-ai-connect/{__version__}",
            }
            resp = await _get_http_client().post(
                f"{self.ctx.api_url}/api/v1/feed",
                json={"message": message},
                headers=headers,
            )
            if resp.status_code < 400:
                try:
                    os.remove(marker)
                except OSError:
                    pass
                logger.info("Update outcome posted to the feed: %s", message)
            else:
                logger.warning(
                    "Feed post for the update outcome failed (HTTP %s); retrying next start",
                    resp.status_code,
                )
        except Exception as e:
            logger.warning("Could not report the update outcome: %s", e)

    def _record_chat_turn(self, task_id: str, user_msg: str, assistant_msg: str) -> None:
        """Append a (user, assistant) pair to a task's chat history.

        Trims each side to MAX_HISTORY_CHARS_PER_TURN, caps total turns at
        MAX_CHAT_HISTORY_TURNS, and prunes oldest tasks if we cross
        MAX_TRACKED_SESSIONS distinct conversations — keeping locks in
        lockstep so the lock map can't leak past the history map.
        """
        if not assistant_msg:
            return
        history = self._chat_history.setdefault(task_id, [])
        history.append({
            "user": user_msg[:MAX_HISTORY_CHARS_PER_TURN],
            "assistant": assistant_msg[:MAX_HISTORY_CHARS_PER_TURN],
        })
        if len(history) > MAX_CHAT_HISTORY_TURNS:
            self._chat_history[task_id] = history[-MAX_CHAT_HISTORY_TURNS:]
        if len(self._chat_history) > MAX_TRACKED_SESSIONS:
            # Drop the oldest half of history AND lock entries together.
            drop = list(self._chat_history.keys())[: MAX_TRACKED_SESSIONS // 2]
            for k in drop:
                self._chat_history.pop(k, None)
                self._task_locks.pop(k, None)

    @staticmethod
    def _protocol_text(metadata: dict) -> str:
        """The L1 platform protocol from a composed dispatch ('' if absent).

        Session-scoped standing text: rendered once per fresh Claude
        session (the session's own transcript carries it across resumes),
        never re-sent into a warm session.
        """
        proto = metadata.get("protocol")
        if isinstance(proto, dict):
            text = proto.get("text")
            if isinstance(text, str) and text.strip():
                return text.strip()
        return ""

    @staticmethod
    def _render_composed_prompt(
        metadata: dict, frame: dict, work_text: str
    ) -> tuple[str, str]:
        """Render a composed dispatch into the session prompt, per the
        assembly contract of the instruction-hierarchy spec:

            blocks (labeled sections) -> frame line -> body -> [Next steps]

        Returns (standing_text, event_text). Standing blocks (identity,
        scope, activity) hold across turns, so _execute_via_session renders
        them only on a fresh launch, exactly like the protocol; a resumed
        session already carries them in its transcript. The event text is
        rendered on every dispatch.

        The protocol is NOT included here — it is prepended only on fresh
        launches (see _execute_via_session). Every field is shape-checked;
        a malformed section is dropped, never fatal.
        """
        standing: list[str] = []
        parts: list[str] = []
        for block in metadata.get("blocks") or []:
            if not isinstance(block, dict):
                continue
            text = block.get("text")
            if not isinstance(text, str) or not text.strip():
                continue
            label = block.get("label")
            if isinstance(label, str) and label.strip():
                section = f"[{label.strip()}]\n{text.strip()}"
            else:
                section = text.strip()
            if block.get("kind") in STANDING_BLOCK_KINDS:
                standing.append(section)
            else:
                parts.append(section)
        rendered_frame = frame.get("rendered")
        if isinstance(rendered_frame, str) and rendered_frame.strip():
            parts.append(rendered_frame.strip())
        if work_text.strip():
            parts.append(work_text.strip())
        next_steps = metadata.get("next_steps")
        if isinstance(next_steps, str) and next_steps.strip():
            parts.append("[Next steps]\n" + next_steps.strip())
        return "\n\n".join(standing), "\n\n".join(parts)

    @staticmethod
    def _format_instructions_block(
        agent_instructions: str, skill_instructions: str
    ) -> str:
        """Format platform-authored persona context for the spawned prompt.

        agent_instructions come from the agent's edit page ("Instructions"
        section); skill_instructions are the invoked skill's per-skill
        text, present only when the dispatch carried a matching
        `skill_used`. Returns "" when neither is set, so callers can
        unconditionally concatenate.
        """
        parts: list[str] = []
        if agent_instructions:
            parts.append(
                "[Agent instructions — authored by your creator on the "
                "platform; follow them throughout]\n" + agent_instructions
            )
        if skill_instructions:
            parts.append(
                "[Skill instructions for this request]\n" + skill_instructions
            )
        if not parts:
            return ""
        return "\n\n".join(parts) + "\n\n"

    @staticmethod
    def _bridge_context_primer_background(trigger_reason: str = "") -> str:
        """Prepend at the top of a spawned-Claude prompt to disambiguate mode.

        For trigger-initiated spawns: tells Claude explicitly that no user
        is watching this session. Without this, Claude can default to
        chat-style behavior (asking questions inline and waiting), which
        for autonomous work means waiting indefinitely — there's no one
        there to answer. Steers it toward `send_inbox_item` for any
        communication.
        """
        reason_clause = f" reason={trigger_reason}" if trigger_reason else ""
        return (
            f"[Context: background work{reason_clause} — no user is actively "
            "watching this session. Use `send_inbox_item` for any "
            "communication you need; don't ask questions inline and wait "
            "for replies.]\n\n"
        )

    @staticmethod
    def _bridge_context_primer_chat(chat_id: str, prior_turns: int) -> str:
        """Prepend at the top of a chat-spawned Claude prompt.

        Tells Claude this is a live interactive session — the user IS
        watching, communicate normally. Reinforces the CLAUDE.md
        active-chat-vs-background distinction so behavior is locked in
        from the first token.
        """
        turn_clause = (
            f"turn {prior_turns + 1} of this thread"
            if prior_turns
            else "first turn"
        )
        return (
            f"[Context: active chat with a user on Society AI "
            f"(chat_id={chat_id}, {turn_clause}). The user is typing live "
            "and watching your work in the agent console panel. "
            "Communicate normally — ask questions inline, narrate progress "
            "inline. Don't drop inbox items at them.]\n\n"
        )

    def _build_chat_prompt(self, user_text: str, history: list[dict[str, str]]) -> str:
        """Construct a single-shot prompt that inlines prior conversation.

        We deliberately don't use `claude --resume` because reloading a session
        with extended-thinking blocks fails Anthropic's integrity check
        (HTTP 400: "thinking blocks cannot be modified"). Inlining the
        cleaned (user, assistant) pairs preserves the conversational
        context without that hazard.
        """
        if self._sandbox:
            env_note = (
                "You are running inside an isolated sandbox. You do not have access "
                "to the user's local files; use the Society AI MCP tools and any "
                "cloud APIs you've been granted to do the work."
            )
        else:
            env_note = (
                "You are running on the user's machine in their working directory. "
                "You may read and modify files there as part of the answer if helpful."
            )

        if not history:
            return (
                "You received a direct message from a user on Society AI.\n\n"
                f"Environment: {env_note}\n\n"
                f"User message: {user_text}\n\n"
                "Respond helpfully."
            )

        history_block = "\n\n".join(
            f"User: {turn['user']}\nYou: {turn['assistant']}"
            for turn in history
        )
        return (
            "You are continuing a conversation with a user on Society AI.\n\n"
            f"Environment: {env_note}\n\n"
            "Prior conversation in this thread:\n"
            f"{history_block}\n\n"
            "New message from the user:\n"
            f"{user_text}\n\n"
            "Respond helpfully, with awareness of the prior exchange."
        )

    async def _execute_chat_task(
        self,
        task_id: str,
        user_text: str,
        agent_task_id: str | None = None,
        instructions_block: str = "",
        chat_id: str = "",
    ):
        """Handle a direct chat message OR a personal-task trigger.

        Each call spawns a fresh streaming `claude -p` session — no `--resume`,
        per the v0.2.2 history fix. Intermediate work (tool calls, thinking
        markers, etc.) is forwarded to the Society AI chat UI as `task.status`
        DataParts; the final text goes out as `task.complete`.

        ``agent_task_id`` distinguishes a real chat (None) from a personal-task
        trigger (UUID present). The context primer flips accordingly so Claude
        doesn't try to chat with a user who isn't there (trigger case) or go
        silent on a user who is (chat case).
        """
        history = list(self._chat_history.get(task_id, []))
        is_followup = bool(history)
        # Fallback detection: chat-path triggers carry a [Trigger: ...] prefix
        # in user_text even when agent_task_id metadata is somehow missing.
        is_background = bool(agent_task_id) or user_text.lstrip().startswith("[Trigger:")
        logger.info(
            "Chat task %s: %s (followup=%s, prior_turns=%d, background=%s)",
            task_id, user_text[:100], is_followup, len(history), is_background,
        )

        primer = (
            self._bridge_context_primer_background(trigger_reason="task")
            if is_background
            else self._bridge_context_primer_chat(task_id, len(history))
        )
        prompt = primer + instructions_block + self._build_chat_prompt(user_text, history)

        if self._sandbox:
            # Secured mode still uses the legacy non-streaming runner. Streaming
            # support in the sandbox is a v0.4.x follow-up — it requires routing
            # stdout through SSH line-by-line, which the current SandboxManager
            # doesn't expose.
            exit_code, output, _ = await self._sandbox.exec_claude(prompt)
            result_text = (output or "").strip() or "I couldn't generate a response."
            if exit_code == 0:
                self._record_chat_turn(task_id, user_text, result_text)
            await self._send_task_complete(task_id, result_text, exit_code)
            return

        exit_code, output, _session, had_error = await stream_claude_code(
            prompt, work_dir=self.ctx.work_dir, extra_dirs=self.ctx.extra_dirs,
            chat_id=chat_id)

        result_text = (output or "").strip() or "I couldn't generate a response."

        if exit_code == 0 and not had_error:
            self._record_chat_turn(task_id, user_text, result_text)

        await self._send_task_complete(
            task_id, result_text, exit_code or (1 if had_error else 0),
        )

    async def _execute_agentorg_task(
        self,
        task_id: str,
        company_id: str,
        agent_task_id: str,
        instructions_block: str = "",
    ):
        """Handle an AgentOrg task — fetch context, spawn Claude Code, report results."""
        company = await fetch_company_details(company_id)
        if not company:
            company = {"name": "Unknown", "mission": "", "goals": []}

        task = await fetch_task_details(company_id, agent_task_id) if agent_task_id else None

        if not task:
            logger.warning(
                "Could not fetch task details for %s, using trigger message",
                agent_task_id,
            )
            task = {
                "id": agent_task_id or task_id,
                "identifier": "UNKNOWN",
                "title": "Check task queue",
                "description": (
                    "A trigger was received but task details could not be fetched. "
                    "Use list_tasks to find your assigned tasks."
                ),
                "acceptanceCriteria": [],
                "companyId": company_id,
            }

        # Prepend mode primer so Claude knows up-front this is background
        # work — the existing build_prompt() instructions already cover the
        # right behaviors near the bottom of the prompt, but the primer at
        # the top removes any ambiguity about whether a user is watching.
        prompt = (
            self._bridge_context_primer_background(trigger_reason="agentorg-task")
            + instructions_block
            + build_prompt(company, task, sandboxed=bool(self._sandbox))
        )
        logger.info(
            "Executing task: %s — %s",
            task.get("identifier", "unknown"), task.get("title", "unknown"),
        )

        if self._sandbox:
            exit_code, output, _ = await self._sandbox.exec_claude(prompt)
            result_text = (output or "").strip() or f"Task completed with exit code {exit_code}"
            await self._send_task_complete(task_id, result_text, exit_code)
        else:
            exit_code, output, _session, had_error = await stream_claude_code(
                prompt, work_dir=self.ctx.work_dir, extra_dirs=self.ctx.extra_dirs)
            result_text = (output or "").strip() or f"Task completed with exit code {exit_code}"
            await self._send_task_complete(
                task_id, result_text, exit_code or (1 if had_error else 0),
            )
        logger.info("Task %s completed (exit=%d)", task.get("identifier", task_id), exit_code)

    async def _send_status_update(self, task_id: str, parts: list[dict]):
        """Send a `task.status` JSON-RPC frame with intermediate DataParts
        (today only the delivery state). Same wire format as the OpenClaw
        connector: `final: false`, `state: "working"`; the hub forwards it
        to the chat over SSE.
        """
        if not parts:
            return
        await self.send_rpc(
            "task.status",
            {
                "task_id": task_id,
                "status": {
                    "state": "working",
                    "message": {
                        "role": "agent",
                        "parts": parts,
                    },
                },
                "final": False,
            },
            msg_id=self._next_id(),
        )

    async def _send_task_complete(self, task_id: str, result_text: str, exit_code: int = 0,
                                  files: list[dict] | None = None):
        """Send task.complete to the hub. `files` are file parts (_turn_files) sent after the text: the
        router keeps the ones the agent may open and shares them with the person who asked.

        Long results are truncated to MAX_RESULT_CHARS; we log the original
        length so a missing tail can be diagnosed from the bridge logs.
        TODO: when upload_file is wired up, upload long results to the
        artifact store and replace with a short link instead of truncating.
        """
        original_len = len(result_text or "")
        if original_len > MAX_RESULT_CHARS:
            logger.warning(
                "Result for task %s truncated: original=%d chars, cap=%d chars",
                task_id, original_len, MAX_RESULT_CHARS,
            )
            result_text = (
                result_text[:MAX_RESULT_CHARS]
                + f"\n\n... (truncated; original {original_len} chars)"
            )
        await self.send_rpc(
            "task.complete",
            {
                "task_id": task_id,
                "status": {
                    "state": "completed" if exit_code == 0 else "failed",
                    "message": {
                        "role": "agent",
                        "parts": [{"type": "text", "text": result_text}, *(files or [])],
                    },
                },
                "final": True,
            },
            msg_id=self._next_id(),
        )

    # -- Session-mode dispatch (v0.7) ----------------------------------------

    @staticmethod
    def _derive_session_title(user_text: str) -> str:
        """Human title for a session: the task's own title when the dispatch
        is a task trigger, else the first meaningful line. Trigger banners
        ('[Trigger: ...]') never become titles."""
        m = re.search(r"new task \([A-Z0-9-]+\):\s*(.+)", user_text)
        if m:
            return m.group(1).strip()[:60]
        for line in user_text.strip().splitlines():
            line = re.sub(r"^\[Trigger:[^\]]*\]\s*", "", line.strip())
            if line:
                return line[:60]
        return "chat"

    async def _on_session_reap(self, rec) -> None:
        """SessionManager reap callback: ship the final transcript delta and
        flip the platform mirror to 'ended'."""
        if self._shipper is not None:
            await self._shipper.ship(rec.session_id, status="ended")

    async def _mirror_retry_loop(self) -> None:
        """Re-ship mirror batches whose status flip failed (network blip at
        reap time) — the session_ended wake and the Scribe depend on the
        'ended' flip reaching the platform."""
        while True:
            try:
                n = await self._shipper.retry_pending()
                if n:
                    logger.info("Mirror retry: re-shipped %d pending session(s)", n)
            except Exception:
                logger.exception("mirror retry loop error")
            await asyncio.sleep(120)

    async def _on_mirror_chat_link(self, session_id: str, chat_id: str) -> None:
        """The platform told us which chat a session projects into. Alias
        that chat id to the session's work item, so a user replying in the
        chat composer continues the SAME Claude Code session."""
        mgr = self._session_mgr
        if mgr is None:
            return
        for rec in list(mgr._sessions.values()):
            if rec.session_id == session_id:
                mgr.alias(chat_id, rec.work_item_key)
                mgr.set_chat(rec.work_item_key, chat_id, only_if_empty=True)
                logger.info(
                    "Chat %s aliased to session work item %s",
                    chat_id[:8], rec.work_item_key[:24],
                )
                return

    async def ipc_session_start(self, params: dict) -> Optional[dict]:
        """IPC from the UserPromptSubmit hook at a session's first message:
        register it if it is to be mirrored and tracked, and answer the banner
        facts (D37). None unless this bridge is the machine's tracking runner,
        so the hook takes the one real answer."""
        if self._tracker is None:
            return None
        try:
            return await self._tracker.session_start(params)
        except Exception:
            logger.exception("session_start failed")
            return None

    async def ipc_session_live(self, params: dict) -> bool:
        """IPC from the PreToolUse and Notification hooks (hook_live.py): a
        tool start (nothing about the tool) or a permission prompt in a session, for the Sessions live
        view. True when this bridge is the machine's tracking runner and took
        it, so the hook stops there."""
        if self._tracker is None:
            return False
        try:
            return self._tracker.live_event(params)
        except Exception:
            logger.exception("session_live failed")
            return False

    def _adopt_direct_session(self, session_id: str, params: dict) -> None:
        """Register a mirrored direct session with this bridge's shipper when the
        tracking runner (any bridge on this machine) recorded it for this agent,
        and hand one over when it moved to another agent (the person switched
        agents in it, D65): that agent's bridge records it from then on. The
        recording is keyed by session, so the new bridge's first batch (from the
        transcript's start) adds nothing twice."""
        if self._shipper is None:
            return
        from agents.claude_code.runner import session_tracker as trk
        try:
            data = json.loads((trk.BASE_DIR / "state.json").read_text())
        except (OSError, ValueError):
            return
        st = (data.get("sessions") or {}).get(session_id) or {}
        if self._shipper.is_registered(session_id):
            owner = st.get("agent")
            if (
                st.get("mirrored") and owner and owner != self.ctx.name
                and self._shipper.work_item_kind(session_id) == "direct"
            ):
                self._shipper.forget(session_id)
                logger.info("Session %s moved to %s: no longer recorded by this bridge", session_id[:8], owner)
            return
        if not st.get("mirrored") or st.get("agent") != self.ctx.name:
            return
        self._shipper.register(
            session_id,
            cwd=str(params.get("cwd") or st.get("cwd") or ""),
            work_item_kind="direct",
            chat_id=str(st.get("chat_id") or ""),
        )
        logger.info("Mirroring session %s started in Claude Code", session_id[:8])

    async def ipc_mirror_notify(self, params: dict) -> dict:
        """IPC from the Stop hook: a Claude Code turn ended on this machine.
        Ships the delta if the session is one the bridge launched; silently
        ignores everything else (the owner's personal sessions are never
        mirrored)."""
        session_id = str(params.get("session_id") or "")
        if not session_id:
            return {"shipped": False}

        # Session Trackers see every session's turns (only the machine's
        # tracking bridge acts on them). Never blocks the hook.
        if self._tracker is not None:
            self._tracker.notify(params)
        if str(params.get("event") or "stop") == "stop":
            waiter = self._direct_turn_events.get(session_id)
            if waiter is not None:
                waiter.set()

        # A session the owner started in Claude Code, for this agent, that the
        # platform said is mirrored and tracked (D36, D37): ship it from now on.
        self._adopt_direct_session(session_id, params)

        # Hook traffic IS session activity. Locally-typed turns never pass
        # through a dispatch, and before this the idle reaper counted them
        # as silence — it once killed a session fifteen seconds after the
        # owner sent a message in it.
        if self._session_mgr is not None:
            self._session_mgr.touch_by_session_id(session_id)

        # 'prompt' = UserPromptSubmit: the owner just typed into this session.
        # Ship soon so the message reaches the platform (and the web app
        # watching the chat) NOW, not at turn end — but in the background,
        # because this hook blocks the turn from starting until it returns,
        # and on a delay, because the prompt entry is flushed to the
        # transcript as the turn spins up, not synchronously with the hook.
        # Two staggered ships cover a slow flush; each is incremental and a
        # no-op when there is nothing new. The turn is NOT closed here — it
        # has only just begun.
        # Every hook-triggered ship declares status='active'. A reaped session
        # flips its mirror to 'ended', and nothing used to flip it back when
        # the owner resumed the session from the desktop — the platform (and
        # the web app's poll pacing) permanently believed the conversation
        # was over. Hook traffic is proof of life; say so. Idempotent when
        # the row is already active, and reap still lands 'ended' afterwards.
        if str(params.get("event") or "stop") == "prompt":
            if self._shipper is not None and self._shipper.is_registered(session_id):
                async def _ship_soon() -> None:
                    for delay in (1.0, 3.0):
                        await asyncio.sleep(delay)
                        try:
                            await self._shipper.ship(session_id, status="active")
                        except Exception:
                            logger.exception("prompt ship failed for %s", session_id[:8])
                asyncio.ensure_future(_ship_soon())
                return {"shipped": True, "deferred": True}
            return {"shipped": False}

        ok = False
        if self._shipper is not None and self._shipper.is_registered(session_id):
            ok = await self._shipper.ship(session_id, status="active")
            # The Stop hook can beat the transcript's LAST flush: the final
            # assistant text block is written by the CLI asynchronously, and
            # a single ship taken at hook time reads everything except the
            # answer itself — observed live (ledger ending on activity
            # entries, response stranded on disk, web app showing a question
            # with no reply). Nothing else ships a locally-typed turn until
            # idle-reap 15 minutes later, so chase the flush with a couple
            # of trailing ships. Each is incremental and a no-op when the
            # first read already got everything.
            async def _ship_tail() -> None:
                for delay in (2.0, 6.0):
                    await asyncio.sleep(delay)
                    try:
                        await self._shipper.ship(session_id, status="active")
                    except Exception:
                        logger.exception("tail ship failed for %s", session_id[:8])
            asyncio.ensure_future(_ship_tail())

        # The Stop hook is also how a dispatch learns its turn is over. Ship
        # first so the platform has the transcript before the task completes,
        # then hand the turn's text back to whoever is waiting on it. This
        # runs even when mirroring is off, since it is the response path.
        closed = await self._close_turn_from_transcript(session_id)
        return {"shipped": ok, "turn_closed": closed}

    async def ipc_status(self, params: dict) -> dict:
        """Live in-process state for the local status panel (localhost only,
        via the bridge's unix socket). No secrets, no transcript content —
        connection health, effective config, and the live session list."""
        sessions: list[dict] = []
        if self._session_mgr is not None:
            try:
                sessions = self._session_mgr.snapshot()
            except Exception as e:
                logger.warning("status snapshot failed: %s", e)

        ws_connected = bool(self.ws) and getattr(self.ws, "close_code", None) is None
        return {
            "version": __version__,
            "agent_name": self.ctx.name,
            "pid": os.getpid(),
            "ws_connected": ws_connected,
            "registered": bool(self.registered),
            "api_url": self.ctx.api_url,
            "config": {
                "session_mode": self._session_mode,
                "mirror": MIRROR_SESSIONS,
                "execution_mode": EXECUTION_MODE,
                "work_dir": self.ctx.work_dir,
                "extra_dirs": list(self.ctx.extra_dirs),
            },
            "active_tasks": len(getattr(self, "_active_tasks", []) or []),
            "pending_session_tasks": len(getattr(self, "_pending_session_tasks", {}) or {}),
            "sessions": sessions,
        }

    async def ipc_session_chat(self, params: dict) -> dict:
        """The app Chat a session works in ("" if none), for its MCP server
        to name on calls to the router (System of Record)."""
        key = str(params.get("session_key") or "").strip()
        rec = self._session_mgr.get(key) if self._session_mgr is not None and key else None
        return {"chat_id": rec.chat_id if rec is not None else ""}

    async def ipc_reopen_session(self, params: dict) -> dict:
        """Relaunch a closed session with its history (and its Remote Control
        entry) without sending it anything. The panel's Reopen button."""
        key = str(params.get("work_item_key") or "").strip()
        if not key:
            return {"error": True, "message": "work_item_key is required"}
        if self._session_mgr is None:
            return {"error": True, "message": "session mode is not enabled"}
        if self._session_mgr.get(key) is None:
            return {"error": True, "message": f"no session for {key}"}
        try:
            rec = await self._session_mgr.reopen(key)
        except Exception as e:
            logger.warning("reopen of %s failed: %s", key, e)
            return {"error": True, "message": str(e)}
        if rec.state != "ready":
            return {"error": True, "message": rec.failure or "the session did not start"}
        return {"reopened": True, "work_item_key": rec.work_item_key}

    async def ipc_reap_session(self, params: dict) -> dict:
        """Reap (kill + ship-ended) a single live session by work-item key.
        Lets the panel clear a stuck session without restarting the bridge."""
        key = str(params.get("work_item_key") or "").strip()
        if not key:
            return {"error": True, "message": "work_item_key is required"}
        if self._session_mgr is None:
            return {"error": True, "message": "session mode is not enabled"}
        if self._session_mgr.get(key) is None:
            return {"error": True, "message": f"no live session for {key}"}
        try:
            await self._session_mgr.reap(key)
            return {"reaped": True, "work_item_key": key}
        except Exception as e:
            logger.warning("reap of %s failed: %s", key, e)
            return {"error": True, "message": str(e)}

    @staticmethod
    def _turn_reply(cwd: str, session_id: str, event_id: str) -> tuple[Optional[str], bool]:
        """The prose a session wrote in response to one channel event, and
        whether the turn's last entry is final (stop_reason end_turn,
        stop_sequence or max_tokens). A turn that used a tool has an earlier
        text block with stop_reason tool_use: reading before the final block
        is flushed would return the agent's opening line as its whole answer.

        This is the response, full stop. There is no reply tool: asking the
        model to call one made delivery depend on it choosing to, which it
        often does not for plain chat, and left the desktop and web views
        showing different conversations. The transcript is the same record
        both surfaces are built from, so reading it is what keeps them
        consistent.

        Bounded on both ends: everything after our channel event, stopping
        at the next one, because a later dispatch is a different turn and
        folding it in would attribute the wrong text to this task. Sidechain
        (subagent) entries are skipped; only what the main session actually
        said counts. Assistant turns arrive as one transcript entry per
        content block, so text blocks are joined in order.

        Returns None when our event is not in the transcript at all, which
        is NOT the same as the agent saying nothing: a warm session can end
        an earlier turn while ours is still in flight, and treating that as
        an empty answer would complete the task against the wrong turn. ""
        means the event is there and the agent wrote no prose.
        """
        from agents.claude_code.runner.transcript_shipper import transcript_path

        needles = (f'event_id="{event_id}"', f'event_id=\\"{event_id}\\"')
        try:
            with open(transcript_path(cwd, session_id), encoding="utf-8",
                      errors="replace") as fh:
                lines = fh.read().splitlines()
        except FileNotFoundError:
            return None, False
        except OSError as e:
            logger.warning("Could not read transcript for %s: %s", session_id[:8], e)
            return None, False

        start = -1
        for i, raw in enumerate(lines):
            if any(n in raw for n in needles):
                start = i
        if start < 0:
            return None, False

        out: list[str] = []
        last_stop: Optional[str] = None
        for raw in lines[start + 1:]:
            try:
                d = json.loads(raw)
            except (ValueError, TypeError):
                continue
            if not isinstance(d, dict) or d.get("isSidechain"):
                continue
            msg = d.get("message")
            kind = d.get("type")
            if kind == "user" and isinstance(msg, dict):
                content = msg.get("content")
                if isinstance(content, str) and "<channel source=" in content:
                    break  # the next dispatch; this turn is done
                continue
            if kind != "assistant" or not isinstance(msg, dict):
                continue
            last_stop = msg.get("stop_reason")
            for c in msg.get("content", []):
                if isinstance(c, dict) and c.get("type") == "text":
                    text = (c.get("text") or "").strip()
                    # Streaming can re-emit a block; never repeat it.
                    if text and (not out or out[-1] != text):
                        out.append(text)
        return "\n\n".join(out).strip(), last_stop in FINAL_STOP_REASONS

    @staticmethod
    def _turn_files(cwd: str, session_id: str, event_id: str) -> list[dict]:
        """The files the session published with upload_file during one turn, as A2A file parts, so the
        reply carries them to the person who asked (shown as file cards in their chat).

        Same bounded window as _turn_reply: after our channel event, stopping at the next one, main
        session only. A file counts when its upload_file call answered with an artifact_id (the
        /api/v1/artifacts/complete answer). The router checks again that the agent may open each one."""
        from agents.claude_code.runner.transcript_shipper import transcript_path

        needles = (f'event_id="{event_id}"', f'event_id=\\"{event_id}\\"')
        try:
            with open(transcript_path(cwd, session_id), encoding="utf-8", errors="replace") as fh:
                lines = fh.read().splitlines()
        except OSError:
            return []
        start = max((i for i, raw in enumerate(lines) if any(n in raw for n in needles)), default=-1)
        if start < 0:
            return []

        uploads: dict[str, dict] = {}   # upload_file calls by tool_use id, with their input
        files: list[dict] = []
        seen: set[str] = set()
        for raw in lines[start + 1:]:
            try:
                d = json.loads(raw)
            except (ValueError, TypeError):
                continue
            if not isinstance(d, dict) or d.get("isSidechain") or not isinstance(d.get("message"), dict):
                continue
            content = d["message"].get("content")
            if d.get("type") == "user" and isinstance(content, str) and "<channel source=" in content:
                break  # the next dispatch; this turn is done
            if not isinstance(content, list):
                continue
            for c in content:
                if not isinstance(c, dict):
                    continue
                if c.get("type") == "tool_use" and str(c.get("name", "")).endswith("upload_file"):
                    uploads[str(c.get("id"))] = c.get("input") if isinstance(c.get("input"), dict) else {}
                elif c.get("type") == "tool_result" and str(c.get("tool_use_id")) in uploads:
                    answer = _upload_answer(c.get("content"))
                    asked = uploads[str(c.get("tool_use_id"))]
                    artifact_id = str(answer.get("artifact_id") or "")
                    if not artifact_id or answer.get("error") or artifact_id in seen:
                        continue
                    seen.add(artifact_id)
                    meta: dict = {"artifact_id": artifact_id}
                    if isinstance(answer.get("size"), int):
                        meta["size"] = answer["size"]
                    files.append({
                        "type": "file",
                        "file": {
                            "name": str(answer.get("name") or asked.get("name") or "file"),
                            "mimeType": str(answer.get("mime_type") or asked.get("mime_type")
                                            or "application/octet-stream"),
                            # The router requires a uri and replaces it with the app's link.
                            "uri": f"artifact:{artifact_id}",
                        },
                        "metadata": meta,
                    })
        return files

    @staticmethod
    def _turn_api_error(cwd: str, session_id: str, event_id: str) -> Optional[str]:
        """The error Claude Code itself reported for this turn, if any.

        Claude Code writes its own failures into the transcript as an
        assistant entry flagged isApiErrorMessage — an expired login, a
        rate limit, a refused key. No Stop hook follows one, so a turn that
        ends this way is indistinguishable from a slow one: the dispatch sat
        until the full task timeout and the person in chat saw silence.
        Scanning for the flag turns that into an immediate, explainable
        failure.

        Same bounded window as _turn_reply: after our channel event,
        stopping at the next one, main session only.
        """
        from agents.claude_code.runner.transcript_shipper import transcript_path

        needles = (f'event_id="{event_id}"', f'event_id=\\"{event_id}\\"')
        try:
            with open(transcript_path(cwd, session_id), encoding="utf-8",
                      errors="replace") as fh:
                lines = fh.read().splitlines()
        except (FileNotFoundError, OSError):
            return None

        start = -1
        for i, raw in enumerate(lines):
            if any(n in raw for n in needles):
                start = i
        if start < 0:
            return None

        for raw in lines[start + 1:]:
            try:
                d = json.loads(raw)
            except (ValueError, TypeError):
                continue
            if not isinstance(d, dict) or d.get("isSidechain"):
                continue
            msg = d.get("message")
            if d.get("type") == "user" and isinstance(msg, dict):
                content = msg.get("content")
                if isinstance(content, str) and "<channel source=" in content:
                    break  # the next dispatch; this turn is done
                continue
            if not d.get("isApiErrorMessage") or not isinstance(msg, dict):
                continue
            for c in msg.get("content", []):
                if isinstance(c, dict) and c.get("type") == "text":
                    text = (c.get("text") or "").strip()
                    if text:
                        return text
        return None

    @staticmethod
    def _explain_api_error(reported: str) -> str:
        """Turn Claude Code's own error into something the person reading
        chat can act on.

        They are usually not at the machine and have no reason to suspect
        it: from the platform side an expired local login looks exactly like
        a broken agent. Name the host, say what to type, and quote the
        original so the cause is never guessed at.
        """
        host = socket.gethostname().split(".")[0]
        low = reported.lower()
        auth = any(
            hint in low
            for hint in ("login", "authenticate", "authentication",
                         "oauth", "unauthorized", "api key", "credit balance")
        )
        if auth:
            return (
                f"I could not answer: the Claude Code sign-in on **{host}**, the "
                f"computer running this agent, is no longer valid, so your message "
                f"never reached the model.\n\n"
                f"To fix it, on that computer open Terminal and run:\n\n"
                f"    claude\n\n"
                f"then type `/login` and sign in. Nothing else needs changing. "
                f"Send your message again once you have.\n\n"
                f"Claude Code reported: {reported}"
            )
        return (
            f"I could not answer: Claude Code on **{host}**, the computer running "
            f"this agent, reported an error before it could reply.\n\n"
            f"Claude Code reported: {reported}\n\n"
            f"The agent is still connected, so retrying is worthwhile. If it keeps "
            f"happening, check the log on that computer:\n\n"
            f"    ./connect service logs"
        )

    async def _close_turn_from_transcript(self, session_id: str) -> bool:
        """A turn ended in this session. If a dispatch is waiting on it,
        resolve it with what the session said. Returns True if one closed."""
        pending = self._session_awaiting.get(session_id)
        if not pending:
            return False
        task_id = pending["task_id"]
        fut = self._pending_session_tasks.get(task_id)
        if not isinstance(fut, asyncio.Future) or fut.done():
            return False

        # The Stop hook can beat the transcript's last flush: the final text
        # block is written a moment later. Wait (briefly) for the turn's last
        # entry to be final; a turn that used a tool otherwise comes back as
        # just its opening line. If it never turns final (a refusal with no
        # fallback, an odd stop reason), take what is there.
        text: Optional[str] = None
        deadline = time.time() + TURN_FINAL_WAIT_S
        while True:
            text, final = self._turn_reply(pending["cwd"], session_id, task_id)
            if text is not None and final:
                break
            if time.time() >= deadline:
                if text is not None:
                    logger.warning("Turn for task %s never reached a final entry; using %d chars",
                                   task_id, len(text))
                break
            await asyncio.sleep(0.3)

        if text is None:
            # A turn ended, but not ours — our event is not in the transcript
            # yet. Leave the watch in place for the Stop that does belong to
            # us rather than completing the task with someone else's silence.
            logger.info(
                "Turn ended in session %s before task %s landed; still waiting",
                session_id[:8], task_id,
            )
            return False

        if not fut.done():
            fut.set_result(text)
        logger.info(
            "Turn closed for task %s from session %s (%d chars)",
            task_id, session_id[:8], len(text),
        )
        return True

    async def _deliver_to_session(
        self,
        channel_key: str,
        session_id: str,
        cwd: str,
        content: str,
        meta: dict,
        *,
        attempts: int = 3,
        ack_timeout_s: float = 15.0,
    ) -> bool:
        """Push a channel event and confirm the session actually took it.

        A push that lands before the client has attached its channel handler
        is discarded silently: the write to the hub socket succeeds, the
        notification reaches the session's stdio, and nothing happens. The
        only trustworthy acknowledgement is the session's own transcript,
        where Claude Code records the injected event (a queue-operation
        entry, then the user turn) tagged with our event_id.

        Delivery is therefore at-least-once: push, watch the transcript, and
        re-push if the event never shows up. A retry can in principle double
        up if the first push lands in the moment between the last check and
        the re-push; we re-check immediately before each retry to keep that
        window as small as it can be. Returns True once acknowledged.
        """
        from agents.claude_code.runner.transcript_shipper import transcript_path

        hub = self._channel_hub
        event_id = str(meta.get("event_id") or "")
        # The transcript stores the channel tag inside a JSON string, so the
        # attribute quotes arrive escaped. Match both forms rather than
        # depending on how the entry happens to be serialized.
        needles = (
            [f'event_id="{event_id}"', f'event_id=\\"{event_id}\\"']
            if event_id
            else []
        )
        path = transcript_path(cwd, session_id)

        def acked() -> bool:
            # No event_id means nothing to correlate on; treat the push as
            # fire-and-forget rather than retrying blind.
            if not needles:
                return True
            # Only the tail can hold an event we pushed seconds ago, and a
            # resumed session's transcript can be megabytes. Read the last
            # chunk rather than the whole file, once per second.
            try:
                with open(path, "rb") as fh:
                    fh.seek(0, os.SEEK_END)
                    fh.seek(max(0, fh.tell() - _ACK_TAIL_BYTES), os.SEEK_SET)
                    tail = fh.read()
            except FileNotFoundError:
                return False
            except OSError as e:
                logger.warning("Could not read transcript %s: %s", path, e)
                return False
            text = tail.decode("utf-8", "replace")
            return any(n in text for n in needles)

        for attempt in range(1, attempts + 1):
            if attempt > 1 and acked():
                return True
            pushed = await hub.push_event(channel_key, content, meta)
            if not pushed:
                logger.warning(
                    "Channel push %d/%d for %s returned not-connected",
                    attempt, attempts, channel_key,
                )
            deadline = time.time() + ack_timeout_s
            while time.time() < deadline:
                await asyncio.sleep(1.0)
                if acked():
                    if attempt > 1:
                        logger.info(
                            "Channel event %s acknowledged on attempt %d",
                            event_id, attempt,
                        )
                    return True
            logger.warning(
                "Channel event %s not acknowledged by %s within %.0fs "
                "(attempt %d/%d)",
                event_id, channel_key, ack_timeout_s, attempt, attempts,
            )
        return False

    async def _reply_into_direct_session(
        self,
        task_id: str,
        session,
        content: str,
        delivery_chat_id: str | None,
        timeout_s: float,
        had_attachments: bool,
    ) -> None:
        """Carry the owner's message from a chat page into the session they
        started in Claude Code, and return its reply (design D28, D29).

        Running: the relay delivers it and the reply is read from the
        transcript. Closed: `claude -p --resume` runs one turn in it under the
        same id and returns the reply."""
        from agents.claude_code.runner import direct_reply as dr
        from agents.claude_code.runner import session_tracker as trk

        def report(state: str) -> None:
            if delivery_chat_id:
                asyncio.ensure_future(self._report_delivery(delivery_chat_id, state))
                asyncio.ensure_future(self._stream_delivery(task_id, state))

        transcript = dr.transcript_of(session)
        if not transcript.is_file():
            report("unreachable")
            await self._send_task_complete(
                task_id, "This session is no longer on this computer.", exit_code=1)
            return
        if had_attachments:
            content += "\n\n(Files attached in Society AI cannot reach a session started in Claude Code yet.)"

        mode = dr.permission_mode(transcript)
        live = trk.running_session(session.session_id)
        event = self._direct_turn_events.setdefault(session.session_id, asyncio.Event())
        try:
            if live is None:
                report("received")
                if self._shipper is not None:
                    # Already in the chat: its mirrored copy must not show twice.
                    self._shipper.expect_app_turn(session.session_id, content)
                text = await dr.ask_closed_session(session, content, mode, timeout_s)
                await self._send_task_complete(
                    task_id, text or "(no reply)", exit_code=0)
                return
            name = str(live.get("name") or "").strip()
            if not name:
                raise dr.DirectReplyError(
                    "This session has no name Claude Code can address. Continue it in Claude Code.")
            start = transcript.stat().st_size
            event.clear()
            msg_id = await dr.relay(name, content, mode)

            deadline = asyncio.get_event_loop().time() + dr.DELIVERY_WAIT_S
            after = None
            while after is None and asyncio.get_event_loop().time() < deadline:
                after = dr.find_delivered(transcript, start, msg_id)
                if after is None:
                    await asyncio.sleep(1.0)
            if after is None:
                report("received")
                await self._send_task_complete(
                    task_id,
                    "Your message is waiting in Claude Code: the session asks you to accept "
                    "messages from Society AI there. Open it and accept, or reply there.",
                    exit_code=0,
                )
                return
            report("received")

            # The reply ends with the session's Stop hook; the final text is
            # flushed a moment later, so read again shortly after.
            loop = asyncio.get_event_loop()
            deadline = loop.time() + timeout_s
            text = ""
            while loop.time() < deadline:
                try:
                    await asyncio.wait_for(event.wait(), timeout=min(5.0, deadline - loop.time()))
                except asyncio.TimeoutError:
                    continue
                event.clear()
                for delay in (2.0, 4.0):
                    await asyncio.sleep(delay)
                    text = dr.reply_after(transcript, after)
                    if text:
                        break
                if text:
                    break
            if not text:
                text = dr.reply_after(transcript, after)
            await self._send_task_complete(
                task_id,
                text or "The session did not answer within the time limit. Continue it in Claude Code.",
                exit_code=0 if text else 1,
            )
        except dr.DirectReplyError as e:
            report("unreachable")
            await self._send_task_complete(task_id, str(e), exit_code=1)
        finally:
            self._direct_turn_events.pop(session.session_id, None)

    async def _execute_via_runner(
        self,
        task_id: str,
        work_item_key: str,
        content: str,
        standing_text: str = "",
        sender: Sender | None = None,
        permission: str | None = None,
        delivery_chat_id: str | None = None,
        attachments: list[Attachment] | None = None,
    ) -> None:
        """Run one turn through the agent type's runner (core/runner.py) and complete the A2A task with its
        reply. core already decided the sender, the conversation and the prompt; the runner only runs it.
        The message's files are downloaded first and named in the prompt, as for Claude Code sessions."""
        from core.runner import ConversationRef, Turn

        owner = sender is None or sender.is_owner
        if attachments:
            content = content + "\n\n" + await self._runner_attachments(attachments, sender, owner, delivery_chat_id)

        if delivery_chat_id:
            asyncio.ensure_future(self._report_delivery(delivery_chat_id, "received"))
            asyncio.ensure_future(self._stream_delivery(task_id, "received"))
        session = self._runner_sessions.get(work_item_key)
        try:
            if session is None:
                session = await self._runner.start(ConversationRef(work_item_key, cwd=self.ctx.work_dir))
                self._runner_sessions[work_item_key] = session
            prompt = f"{standing_text}\n\n{content}" if standing_text else content
            turn = Turn(task_id, prompt, owner=owner, permission=permission)
            final, error = None, None
            async for event in self._runner.run(session, turn):
                if event.kind == "final":
                    final = event.text
                elif event.kind == "error":
                    error = event.text
        except Exception as e:  # noqa: BLE001 - the runner failing must still answer the task
            logger.exception("Runner failed on %s", task_id)
            self._runner_sessions.pop(work_item_key, None)
            error = f"{AGENT_TYPE} could not run: {e}"
        if error is not None:
            await self._send_task_complete(task_id, error, exit_code=1)
        else:
            await self._send_task_complete(task_id, final or "(no reply)")

    async def _runner_attachments(self, attachments: list[Attachment], sender: Sender | None, owner: bool,
                                  delivery_chat_id: str | None) -> str:
        """Download a runner turn's files and return the prompt's [Attachments] section. The owner's land in
        the agent's work folder; a contact's in that contact's own session folder, so one contact's file is
        never in another's (the same rule as Claude Code sessions)."""
        if owner or sender is None:
            base = pathlib.Path(self.ctx.work_dir)
        else:
            base = folders.session_dir(sender.group, self.ctx.name, os.getenv("DISPLAY_NAME", "").strip())
        fetched = await fetch_all(
            _get_http_client(), self.ctx.api_url, self.ctx.token, attachments, base / FILES_DIRNAME,
            chat_id=delivery_chat_id or "",
        )
        # download_file is a Claude Code bridge tool: other runtimes are not told to use it.
        return prompt_block(fetched, can_get_file=False, claude_code=False)

    async def _execute_via_session(
        self,
        task_id: str,
        work_item_key: str,
        title: str,
        content: str,
        kind: str,
        timeout_s: float = 600.0,
        protocol_text: str = "",
        standing_text: str = "",
        sender: Sender | None = None,
        permission: str | None = None,
        delivery_chat_id: str | None = None,
        attachments: list[Attachment] | None = None,
        inbox_chat: str = "",
    ) -> None:
        """Dispatch a work item into a persistent session and wait for its
        reply, then complete the A2A task. The event_id we send IS the A2A
        task_id, so the reply correlates straight back.

        `permission` is None for the owner; for a contact it is the level
        the session is launched (or relaunched) with. `delivery_chat_id`
        names the owner's chat whose message gets delivery ticks.
        `inbox_chat` is set for the owner's answer to something the agent
        asked: the chat it asked from (inbox_answer_chat)."""
        # A session the owner started in Claude Code itself: its chat page
        # sends here, but it has no channel. The relay carries the message,
        # and an answer to what such a session asked goes back the same way.
        if (kind == "chat" or inbox_chat) and (sender is None or sender.is_owner):
            from agents.claude_code.runner.direct_reply import direct_session_for_chat
            direct = direct_session_for_chat(inbox_chat or delivery_chat_id or work_item_key)
            if direct is not None:
                await self._reply_into_direct_session(
                    task_id, direct, content, delivery_chat_id, timeout_s, bool(attachments),
                )
                return

        mgr = self._session_mgr
        hub = self._channel_hub

        def report(state: str) -> None:
            if delivery_chat_id:
                asyncio.ensure_future(self._report_delivery(delivery_chat_id, state))
                # Also on the reply stream the page already has open, so the
                # tick moves the moment it happens instead of on its next poll.
                asyncio.ensure_future(self._stream_delivery(task_id, state))

        existing = mgr.get(work_item_key)
        if existing is None or existing.state != "ready":
            report("waking")  # a cold start or a reopen takes several seconds

        # The message's files download while the session starts. The owner's
        # land in the agent's work folder; a contact's in that contact's own
        # session folder, where no other contact (and none of the owner's
        # sessions) works, so one contact's file is never visible to another.
        is_contact = sender is not None and not sender.is_owner
        fetch_task = None
        if attachments:
            if is_contact:
                pol = mgr.policy(self.ctx.name)
                base = (existing.cwd if existing is not None and existing.cwd
                        else str(folders.session_dir(sender.group, self.ctx.name, pol.display_name)))
            else:
                base = self.ctx.work_dir
            fetch_task = asyncio.ensure_future(fetch_all(
                _get_http_client(), self.ctx.api_url, self.ctx.token,
                attachments, pathlib.Path(base) / FILES_DIRNAME,
                chat_id=delivery_chat_id or (existing.chat_id if existing is not None else ""),
            ))
        # Ensure (launch or resume) the work item's session. Trigger-kind
        # work (wakes, schedules, status echoes) runs headless, with no Remote
        # Control sidebar row, except the owner's answer to something the
        # session asked: the owner follows that session, so it shows in
        # Claude Code like their chats do.
        try:
            rec = await mgr.ensure_session(
                work_item_key, self.ctx.name,
                # An answer continues the session that asked, under its own name.
                title=(existing.title if inbox_chat and existing is not None else title),
                background=(kind == "trigger" and not inbox_chat),
                permission=permission,
                contact_label=sender.label if sender is not None and not sender.is_owner else "",
                sender_group=sender.group if sender is not None and not sender.is_owner else "",
                # The owner's chat this message came from is where the
                # session's actions happen (System of Record).
                chat_id=delivery_chat_id or "",
            )
        except Exception as e:
            logger.exception("Session launch failed for %s", work_item_key)
            report("unreachable")
            await self._send_task_complete(
                task_id, f"Could not start a session: {type(e).__name__}: {e}", exit_code=1
            )
            return

        # Session-scoped standing context: the L1 platform protocol and the
        # standing blocks (identity, scope, activity). A fresh launch has no
        # context — lead with them; resumes and warm sessions already carry
        # them in their transcript, so re-sending is pure token waste.
        # Instruction edits therefore land on the next new session, not
        # mid-conversation, which is the intended behaviour.
        if getattr(rec, "fresh_launch", False):
            preamble = "\n\n".join(p for p in (protocol_text, standing_text) if p)
            if preamble:
                content = preamble + "\n\n" + content

        # Register the session for transcript mirroring, linked to the work
        # item that caused it. 'task' = a real platform task (agent_task_id);
        # 'trigger' = platform automation (orchestrator wakes, schedules) —
        # the distinction loop-guards the supervisor: scribe sessions ending
        # never re-wake the orchestrator.
        is_contact = sender is not None and not sender.is_owner
        record = not is_contact or mgr.policy(self.ctx.name).mirror_contacts
        if sender is not None and sender.session:
            # Society AI updates stay on the agent's side: never a Society AI chat.
            record = False
        if self._shipper is not None and record:
            if kind == "chat":
                wi_kind = "chat"
            elif kind == "task_assigned":
                wi_kind = "task"
            else:
                wi_kind = "trigger"
            self._shipper.register(
                rec.session_id,
                cwd=mgr.session_cwd(rec),
                title=title,
                work_item_kind=wi_kind,
                work_item_id=work_item_key,
                contact=(
                    {"sender": sender.label, "permission": permission}
                    if sender is not None and not sender.is_owner else None
                ),
                chat_id=rec.chat_id,
            )

        if rec.state != "ready":
            report("unreachable")
            await self._send_task_complete(
                task_id, rec.failure or "Could not start a Claude Code session.", exit_code=1
            )
            return

        # An aliased dispatch (e.g. a reply typed in the session's platform
        # chat) resolves to the canonical work item — the channel registered
        # under that key, so all hub operations use it.
        channel_key = rec.work_item_key

        # Wait briefly for the session's channel to connect (fresh launches
        # connect within ~1-2s; resumes faster).
        for _ in range(40):
            if hub.is_connected(channel_key):
                break
            await asyncio.sleep(0.25)
        if not hub.is_connected(channel_key):
            logger.error(
                "Channel for %s (session %s) did not connect to %s within 10s",
                channel_key, rec.session_id[:8], hub.path,
            )
            report("unreachable")
            await self._send_task_complete(
                task_id, "Session started but its channel did not connect in time.", exit_code=1
            )
            return

        if fetch_task is not None:
            # download_file is only in sessions that load the society-ai MCP:
            # the owner's, and "act" contacts'.
            fetched = await fetch_task
            content = content + "\n\n" + prompt_block(
                fetched, can_get_file=not is_contact or permission == "act"
            )

        loop = asyncio.get_event_loop()
        fut: asyncio.Future = loop.create_future()
        self._pending_session_tasks[event_id := task_id] = fut
        # The session's Stop hook resolves this by reading the transcript;
        # registered before delivery so a fast turn cannot end before we are
        # listening for it.
        work_dir = mgr.session_cwd(rec)
        self._session_awaiting[rec.session_id] = {"task_id": task_id, "cwd": work_dir}
        try:
            # Two distinct failures, two distinct timeouts. Delivery either
            # lands in seconds or it never will, and reporting it as "the
            # agent did not reply" points the reader at the model when the
            # message never reached it.
            delivered = await self._deliver_to_session(
                channel_key,
                rec.session_id,
                work_dir,
                content,
                {"event_id": task_id, "kind": kind},
            )
            mgr.touch(channel_key)
            report("received" if delivered else "unreachable")
            if not delivered:
                logger.error(
                    "Delivery failed for task %s into session %s (%s)",
                    task_id, rec.session_id[:8], channel_key,
                )
                await self._send_task_complete(
                    task_id,
                    "The session started but never picked up the message. "
                    "Nothing was lost on your side; sending it again should work.",
                    exit_code=1,
                )
                return
            # Wait for the turn, but keep an eye on the transcript while we
            # do. Claude Code reports its own failures (expired login, rate
            # limit) as an entry no Stop hook follows, so waiting on the
            # future alone burns the entire timeout and answers with silence.
            # Shielded so a poll timeout never cancels the real future.
            deadline = loop.time() + timeout_s
            reported: Optional[str] = None
            text = None
            while True:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    break
                try:
                    text = await asyncio.wait_for(
                        asyncio.shield(fut),
                        timeout=min(self.API_ERROR_POLL_S, remaining),
                    )
                    break
                except asyncio.TimeoutError:
                    reported = self._turn_api_error(work_dir, rec.session_id, task_id)
                    if reported:
                        break

            if reported and text is None:
                logger.error(
                    "Task %s: Claude Code reported an error instead of replying: %s",
                    task_id, reported,
                )
                await self._send_task_complete(
                    task_id, self._explain_api_error(reported), exit_code=1,
                )
                return

            if text is None:
                # The turn never ended: still working past the limit, or the
                # Stop hook never fired. Fall back to whatever the session
                # has written so far rather than discarding a real answer.
                text, _ = self._turn_reply(work_dir, rec.session_id, task_id)
                if text:
                    logger.warning(
                        "Task %s timed out; returning %d chars written so far",
                        task_id, len(text),
                    )
                else:
                    await self._send_task_complete(
                        task_id, "The agent did not finish within the time limit.",
                        exit_code=1,
                    )
                    return
            if sender is not None and sender.session:
                # What the agent writes in a long-lived session (the Lead's updates, a
                # group chat) is for its own context; it acts through tools, in a
                # group with send_group_message. Nothing of it goes back to Society AI.
                text = ("Handled in the updates session." if sender.session == UPDATES_SESSION
                        else "Handled in the group's session.")
            # Files the agent published while answering its owner go back with the reply. Not for a
            # contact: a file uploaded for the owner during that turn must never reach someone else.
            files = (self._turn_files(work_dir, rec.session_id, task_id)
                     if sender is None or (sender.is_owner and not sender.session) else [])
            await self._send_task_complete(task_id, text or "(no reply)", exit_code=0, files=files)
        finally:
            self._pending_session_tasks.pop(task_id, None)
            # Only clear the turn watch if it is still ours: a follow-up
            # dispatch into the same session registers its own, and popping
            # blindly would strand it with nothing listening for its turn.
            if self._session_awaiting.get(rec.session_id, {}).get("task_id") == task_id:
                self._session_awaiting.pop(rec.session_id, None)
            # Ship the turn's transcript delta in the background — never
            # blocks task completion, and failures only log.
            if self._shipper is not None:
                asyncio.ensure_future(self._shipper.ship(rec.session_id))

    # -- Main loop -----------------------------------------------------------

    async def run(self):
        """Connect to hub and process messages with auto-reconnect."""
        # If an update ran while we were down, report how it went (fire and
        # forget — a failed post retries at the next start, never blocks boot).
        asyncio.ensure_future(self._report_update_outcome())

        if self._tracker is not None:
            asyncio.ensure_future(self._tracker.run())

        # Start sandbox in secured mode (hard fail if it can't start)
        if self._sandbox:
            try:
                await self._sandbox.start()
            except Exception as e:
                logger.error("SECURED MODE FAILED: %s", e)
                logger.error(
                    "Cannot run in secured mode. Fix the issue above or use EXECUTION_MODE=standard."
                )
                sys.exit(1)

        # Start session-mode infrastructure (channel hub + session manager),
        # and overlay platform-fetched policy onto this persona.
        if self._session_mode:
            try:
                await self._channel_hub.start()
                self._session_mgr.start()
                if self._shipper is not None:
                    # Retry parked mirror flips: immediately (catches flips
                    # dropped before a restart) and every 2 minutes.
                    asyncio.ensure_future(self._mirror_retry_loop())
                from core.policy import fetch_platform_policy, apply_platform, apply_local_env
                fetched = await fetch_platform_policy(
                    self.ctx.api_url, self.ctx.token, self.ctx.name
                )
                if fetched:
                    pol = self._session_mgr.policy(self.ctx.name)
                    apply_platform(pol, fetched)
                    apply_local_env(pol, self.ctx.name)  # local always wins
                    pol.session_env = self.ctx.session_env()  # keep per-agent env
                    logger.info("Applied platform policy for %s", self.ctx.name)
                pol = self._session_mgr.policy(self.ctx.name)
                pol.owner_label = await self._resolve_owner_label()
                if self._shipper is not None and not pol.mirror_contacts:
                    dropped = self._shipper.forget_contact_sessions()
                    if dropped:
                        logger.info("Stopped recording %d contact session(s) to Society AI", dropped)
            except Exception:
                logger.exception("Session-mode startup failed; falling back to spawn path")
                self._session_mode = False

        reconnect_delay = 1

        while self.running:
            url = ws_url(self.ctx.api_url)
            logger.info("Connecting to %s", url)

            # Get fresh JWT before each connection attempt
            try:
                await self.obtain_jwt()
            except AgentDeletedError as e:
                # Deleted while this computer was off or offline.
                self.remove_self(str(e))
                return
            except AuthError as e:
                # Bad credentials — do not retry endlessly; exit so the user sees it.
                logger.error("%s", e)
                self.running = False
                return
            except Exception as e:
                logger.error("Failed to obtain JWT: %s", e)
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, MAX_RECONNECT_DELAY)
                continue

            try:
                # TLS only for wss:// - websockets rejects an ssl context
                # for plain ws:// (local/dev hubs).
                ssl_ctx = (
                    ssl.create_default_context(cafile=certifi.where())
                    if url.startswith("wss://")
                    else None
                )
                async with websockets.connect(url, ping_interval=None, ssl=ssl_ctx) as ws:
                    self.ws = ws
                    self.registered = False
                    self._registered_event.clear()
                    # NOT reset here. A socket that connects and is then
                    # refused registration would otherwise pin the delay at
                    # 1s and retry forever at a fixed interval, which is
                    # exactly what MAX_RECONNECT_DELAY exists to prevent.
                    # handle_message sets this once the hub accepts us.
                    self._conn_registered = False

                    # Start heartbeat
                    heartbeat = asyncio.create_task(self.heartbeat_loop())
                    registration_watchdog = asyncio.create_task(
                        self._registration_watchdog(ws)
                    )

                    try:
                        async for raw in ws:
                            await self.handle_message(raw)
                    except ConnectionClosed as e:
                        logger.warning("Connection closed: %s", e)
                    finally:
                        for task in (heartbeat, registration_watchdog):
                            task.cancel()
                            try:
                                await task
                            except (asyncio.CancelledError, Exception):
                                pass
                        self.ws = None
                        self.registered = False
                        self._registered_event.clear()

            except InvalidStatus as e:
                # HTTP-level failure on the WS handshake (e.g. 401 from bad JWT)
                logger.error("WS handshake failed: %s", e)
            except Exception as e:
                logger.error("Connection error: %s", e)

            # A connection that got as far as registering was a real one, so
            # the next failure starts its backoff from scratch.
            if self._conn_registered:
                reconnect_delay = 1

            if self.running:
                logger.info("Reconnecting in %ds...", reconnect_delay)
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, MAX_RECONNECT_DELAY)

    def stop(self):
        """Signal the bridge to stop. Safe to call from a signal handler.

        Does NOT await the sandbox shutdown — that happens in main()'s
        finally block where we still control the event loop.
        """
        if not self.running:
            return
        self.running = False
        if self._tracker is not None:
            self._tracker.stop()
        logger.info("Shutting down...")


# -- Delivery ticks -------------------------------------------------------------

def _data_part(component: str, part_id: str, payload: dict) -> dict:
    """A DataPart in the nested shape the chat stream-transformer reads:
    `{type: 'data', data: {component, id, payload}}`."""
    return {"type": "data", "data": {"component": component, "id": part_id, "payload": payload}}


def _owner_chat_id(metadata: dict) -> str | None:
    """The Society AI app chat a dispatch came from, if any (top-level, or
    nested under `context` in stored task metadata)."""
    for source in (metadata, metadata.get("context") if isinstance(metadata.get("context"), dict) else {}):
        chat_id = source.get("chat_id")
        if isinstance(chat_id, str) and chat_id.strip():
            return chat_id.strip()
    return None


# Inbox causes that answer something the agent asked its owner: its inbox item,
# or an action it was told to ask about first.
INBOX_ANSWER_REASONS = ("inbox_responded", "held_action")


def inbox_answer_chat(sender: Sender, frame: dict | None, metadata: dict) -> str:
    """The chat the owner's answer to this agent's inbox item (or held action)
    returns to: the chat the agent asked from, which the router names as the
    dispatch's chat_id. "" for anything else. Only metadata.chat_id counts:
    every dispatch carries a sessionId, a fresh one when there is no chat."""
    if frame is None or not sender.is_owner or sender.session:
        return ""
    if str(frame.get("cause") or "") != "inbox":
        return ""
    if metadata.get("trigger_reason") not in INBOX_ANSWER_REASONS:
        return ""
    return valid_chat_id(metadata.get("chat_id"))


# -- Env files ----------------------------------------------------------------

def _read_env_file(path: str) -> dict:
    """Minimal KEY=value parser for a persona .env file."""
    out: dict[str, str] = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#") or "=" not in s:
                    continue
                if s.startswith("export "):
                    s = s[len("export "):]
                k, _, v = s.partition("=")
                k, v = k.strip(), v.strip()
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                    v = v[1:-1]
                out[k] = v
    except FileNotFoundError:
        pass
    return out


# -- Shutdown -----------------------------------------------------------------

async def _teardown_bridge(bridge: "Bridge") -> None:
    """Per-agent graceful teardown: park ended flips, stop session infra so
    the next start ships the sessions and the Scribe still learns they ended."""
    if bridge._sandbox:
        try:
            await bridge._sandbox.stop()
        except Exception as e:
            logger.warning("sandbox stop (%s): %s", bridge.ctx.name, e)
    if getattr(bridge, "_session_mgr", None):
        if getattr(bridge, "_shipper", None):
            try:
                for rec in list(bridge._session_mgr._sessions.values()):
                    if rec.state == "ready":
                        bridge._shipper.park_status(rec.session_id, "ended")
            except Exception as e:
                logger.warning("park ended flips (%s): %s", bridge.ctx.name, e)
        try:
            await bridge._session_mgr.stop()
        except Exception as e:
            logger.warning("session mgr stop (%s): %s", bridge.ctx.name, e)
    if getattr(bridge, "_channel_hub", None):
        try:
            await bridge._channel_hub.stop()
        except Exception as e:
            logger.warning("channel hub stop (%s): %s", bridge.ctx.name, e)
    if getattr(bridge, "_shipper", None):
        try:
            await bridge._shipper.close()
        except Exception as e:
            logger.warning("shipper close (%s): %s", bridge.ctx.name, e)


# -- Entry point --------------------------------------------------------------

def main():
    # One process per agent. bridge_launcher.sh sources exactly one agent's
    # env file (.env or .env.<persona>) before exec'ing us, so the process
    # env IS the agent.
    global WORK_DIR
    if not WORK_DIR and AGENT_NAME:
        WORK_DIR = str(folders.agent_workspace(AGENT_NAME, os.getenv("DISPLAY_NAME", "").strip()))
    ctx = AgentContext.from_env()
    if not ctx.name or not ctx.token:
        print(
            "Error: AGENT_NAME and SOCIETY_AI_AUTH_TOKEN must be set. Start the "
            "bridge with core/installer/bridge_launcher.sh [persona], or run ./connect setup.",
            file=sys.stderr,
        )
        sys.exit(2)

    cli_version = claude_cli_version()
    logger.info(
        "Society AI Connect bridge v%s on Claude Code CLI %s — agent %s (mode=%s)",
        __version__, cli_version or "unknown", ctx.name, EXECUTION_MODE,
    )
    if cli_version is None:
        logger.error(
            "`claude --version` does not run on this PATH (%s); sessions will "
            "fail to start until Claude Code is reinstalled",
            os.environ.get("PATH", ""),
        )

    bridge = Bridge(ctx)
    ipc = bridge_ipc.IPCServer(
        handlers={
            "mirror_notify": bridge.ipc_mirror_notify,
            "session_start": bridge.ipc_session_start,
            "session_live": bridge.ipc_session_live,
            "status": bridge.ipc_status,
            "reap_session": bridge.ipc_reap_session,
            "reopen_session": bridge.ipc_reopen_session,
            "session_chat": bridge.ipc_session_chat,
        },
        path=ctx.socket,
    )
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    # Owning the agent's sockets is what makes this process the agent on
    # this machine. If another live process already owns them, starting
    # anyway would split the agent between two processes, so stop here.
    try:
        loop.run_until_complete(ipc.start())
    except bridge_ipc.SocketInUseError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    def _request_shutdown():
        logger.info("Shutdown requested")
        bridge.stop()
        # Close the WS so the run loop unblocks and returns — otherwise the
        # process ignores SIGTERM (the read loop stays parked on
        # `async for raw in ws`). launchd stops/restarts via SIGTERM, so this
        # is what lets a clean teardown (parked status flips) happen.
        if bridge.ws is not None:
            asyncio.ensure_future(bridge.ws.close())

    # Prefer loop-native signal handling (runs inside the loop, can schedule
    # the WS close); fall back to plain signals where unavailable.
    for _sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(_sig, _request_shutdown)
        except (NotImplementedError, RuntimeError):
            signal.signal(_sig, lambda *_: _request_shutdown())

    try:
        loop.run_until_complete(bridge.run())
    except KeyboardInterrupt:
        bridge.stop()
    finally:
        if bridge._active_tasks:
            logger.info("Waiting for in-flight tasks...")
            try:
                loop.run_until_complete(asyncio.sleep(2))
            except Exception:
                pass
        try:
            loop.run_until_complete(ipc.stop())
        except Exception as e:
            logger.warning("IPC server stop: %s", e)
        try:
            loop.run_until_complete(_teardown_bridge(bridge))
            loop.run_until_complete(_close_http_client())
        except Exception as e:
            logger.warning("Shutdown error: %s", e)
        try:
            loop.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
